interface GaugeMeterProps {
  value: number;
  min: number;
  max: number;
  label: string;
  unit: string;
  status: 'good' | 'warning' | 'critical';
  size?: 'sm' | 'md' | 'lg';
}

const statusColors = {
  good: { stroke: 'hsl(152, 60%, 42%)', bg: 'hsl(152, 60%, 42%, 0.1)' },
  warning: { stroke: 'hsl(38, 92%, 50%)', bg: 'hsl(38, 92%, 50%, 0.1)' },
  critical: { stroke: 'hsl(0, 72%, 51%)', bg: 'hsl(0, 72%, 51%, 0.1)' },
};

const sizes = {
  sm: { width: 120, strokeWidth: 8, fontSize: 20 },
  md: { width: 160, strokeWidth: 10, fontSize: 28 },
  lg: { width: 200, strokeWidth: 12, fontSize: 36 },
};

export function GaugeMeter({ value, min, max, label, unit, status, size = 'md' }: GaugeMeterProps) {
  const { width, strokeWidth, fontSize } = sizes[size];
  const radius = (width - strokeWidth) / 2;
  const circumference = Math.PI * radius; // half circle
  const percentage = Math.min(Math.max((value - min) / (max - min), 0), 1);
  const offset = circumference * (1 - percentage);
  const colors = statusColors[status];

  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={width} height={width / 2 + 16} viewBox={`0 0 ${width} ${width / 2 + 16}`}>
        {/* Background arc */}
        <path
          d={`M ${strokeWidth / 2} ${width / 2} A ${radius} ${radius} 0 0 1 ${width - strokeWidth / 2} ${width / 2}`}
          fill="none"
          stroke="hsl(200, 12%, 18%)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />
        {/* Value arc */}
        <path
          d={`M ${strokeWidth / 2} ${width / 2} A ${radius} ${radius} 0 0 1 ${width - strokeWidth / 2} ${width / 2}`}
          fill="none"
          stroke={colors.stroke}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1s ease-out', filter: `drop-shadow(0 0 6px ${colors.stroke})` }}
        />
        {/* Value text */}
        <text
          x={width / 2}
          y={width / 2 - 4}
          textAnchor="middle"
          fill={colors.stroke}
          fontSize={fontSize}
          fontFamily="Space Grotesk"
          fontWeight="700"
        >
          {value}
        </text>
        <text
          x={width / 2}
          y={width / 2 + 14}
          textAnchor="middle"
          fill="hsl(200, 10%, 50%)"
          fontSize={11}
          fontFamily="Inter"
        >
          {unit}
        </text>
      </svg>
      <span className="text-sm font-medium text-muted-foreground">{label}</span>
    </div>
  );
}
