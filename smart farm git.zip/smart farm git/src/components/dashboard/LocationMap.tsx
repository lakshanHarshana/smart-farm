import { devices, formatTimeAgo } from '@/lib/mockData';
import { MapPin } from 'lucide-react';

export function LocationMap() {
  return (
    <div className="glass-card p-4 fade-in">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-muted-foreground">Monitoring Locations</h3>
        <MapPin className="w-4 h-4 text-muted-foreground" />
      </div>
      {/* Map placeholder with farm layout */}
      <div className="relative w-full h-48 rounded-lg bg-secondary/50 border border-border overflow-hidden mb-3">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `
            linear-gradient(hsl(152, 60%, 42%, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, hsl(152, 60%, 42%, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '30px 30px',
        }} />
        {/* Device markers */}
        <div className="absolute top-8 left-10 flex flex-col items-center">
          <div className="glow-dot" />
          <span className="text-[9px] text-muted-foreground mt-1">Zone A</span>
        </div>
        <div className="absolute top-12 right-16 flex flex-col items-center">
          <div className="glow-dot" />
          <span className="text-[9px] text-muted-foreground mt-1">Zone B</span>
        </div>
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center">
          <div className="glow-dot" />
          <span className="text-[9px] text-muted-foreground mt-1">Tank A</span>
        </div>
        <div className="absolute bottom-8 right-8 flex flex-col items-center">
          <div className="w-2 h-2 rounded-full bg-destructive opacity-50" />
          <span className="text-[9px] text-muted-foreground mt-1">Zone C</span>
        </div>
        <div className="absolute bottom-2 left-2 text-[9px] text-muted-foreground/60 font-display">
          Farm Layout View
        </div>
      </div>
      {/* Device list */}
      <div className="space-y-2">
        {devices.map(d => (
          <div key={d.id} className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <div className={`w-1.5 h-1.5 rounded-full ${d.status === 'online' ? 'bg-success' : 'bg-destructive/50'}`} />
              <span className="text-foreground">{d.name}</span>
            </div>
            <span className="text-muted-foreground">{formatTimeAgo(d.lastSeen)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
