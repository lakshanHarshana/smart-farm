import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { SensorReading, formatTime } from '@/lib/mockData';

interface TrendChartProps {
  data: SensorReading[];
  title: string;
  color?: string;
  unit?: string;
  height?: number;
  showGrid?: boolean;
}

const chartColors: Record<string, string> = {
  green: 'hsl(152, 60%, 42%)',
  blue: 'hsl(199, 89%, 48%)',
  amber: 'hsl(38, 92%, 50%)',
  purple: 'hsl(280, 65%, 60%)',
  red: 'hsl(0, 72%, 51%)',
};

export function TrendChart({ data, title, color = 'green', unit = '', height = 200, showGrid = true }: TrendChartProps) {
  const strokeColor = chartColors[color] || color;
  const chartData = data.map(d => ({ time: formatTime(d.timestamp), value: d.value }));

  return (
    <div className="glass-card p-4 fade-in">
      <h3 className="text-sm font-medium text-muted-foreground mb-3">{title}</h3>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={chartData}>
          {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="hsl(200, 12%, 14%)" />}
          <XAxis
            dataKey="time"
            stroke="hsl(200, 10%, 35%)"
            fontSize={10}
            tickLine={false}
            axisLine={false}
            interval="preserveStartEnd"
          />
          <YAxis
            stroke="hsl(200, 10%, 35%)"
            fontSize={10}
            tickLine={false}
            axisLine={false}
            width={35}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'hsl(200, 18%, 11%)',
              border: '1px solid hsl(200, 12%, 18%)',
              borderRadius: '8px',
              fontSize: '12px',
              color: 'hsl(140, 10%, 92%)',
            }}
            formatter={(val: number) => [`${val} ${unit}`, title]}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke={strokeColor}
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4, fill: strokeColor, stroke: 'hsl(200, 18%, 11%)', strokeWidth: 2 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
