import { AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { Alert, formatTimeAgo } from '@/lib/mockData';

interface AlertsPanelProps {
  alerts: Alert[];
  title?: string;
  maxItems?: number;
}

const alertStyles = {
  critical: { icon: AlertCircle, bg: 'bg-destructive/10', border: 'border-destructive/30', text: 'text-destructive' },
  warning: { icon: AlertTriangle, bg: 'bg-warning/10', border: 'border-warning/30', text: 'text-warning' },
  info: { icon: Info, bg: 'bg-info/10', border: 'border-info/30', text: 'text-info' },
};

export function AlertsPanel({ alerts, title = 'Recent Alerts', maxItems = 5 }: AlertsPanelProps) {
  const displayed = alerts.slice(0, maxItems);

  return (
    <div className="glass-card p-4 fade-in">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        <span className="text-xs text-muted-foreground">{alerts.length} total</span>
      </div>
      <div className="space-y-2.5">
        {displayed.map((alert) => {
          const style = alertStyles[alert.type];
          const Icon = style.icon;
          return (
            <div key={alert.id} className={`flex items-start gap-3 p-3 rounded-lg ${style.bg} border ${style.border}`}>
              <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${style.text}`} />
              <div className="min-w-0 flex-1">
                <p className="text-sm text-foreground leading-tight">{alert.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{formatTimeAgo(alert.timestamp)}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
