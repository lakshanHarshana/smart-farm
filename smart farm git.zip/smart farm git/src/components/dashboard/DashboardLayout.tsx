import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, Wind, Droplets, Sprout, Bell, Wifi, Menu, X } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/air', icon: Wind, label: 'Air Quality' },
  { to: '/water', icon: Droplets, label: 'Water Quality' },
  { to: '/soil', icon: Sprout, label: 'Soil Moisture' },
];

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const isMobile = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const sidebarContent = (
    <>
      {/* Logo */}
      <div className="p-5 border-b border-sidebar-border">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-primary/20 flex items-center justify-center glow-green">
            <Sprout className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-base font-display font-bold text-foreground">SmartFarm</h1>
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Monitoring System</p>
          </div>
          {isMobile && (
            <button onClick={() => setSidebarOpen(false)} className="ml-auto p-1 rounded-lg hover:bg-sidebar-accent">
              <X className="w-5 h-5 text-muted-foreground" />
            </button>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1">
        {navItems.map(({ to, icon: Icon, label }) => {
          const isActive = location.pathname === to;
          return (
            <NavLink
              key={to}
              to={to}
              onClick={() => isMobile && setSidebarOpen(false)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${isActive
                  ? 'bg-primary/15 text-primary'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
            >
              <Icon className="w-4.5 h-4.5" />
              {label}
            </NavLink>
          );
        })}
      </nav>

      {/* Status */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="glow-dot" />
          <span>5 devices online</span>
        </div>
      </div>
    </>
  );

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Desktop Sidebar */}
      {!isMobile && (
        <aside className="w-64 shrink-0 bg-sidebar border-r border-sidebar-border flex flex-col">
          {sidebarContent}
        </aside>
      )}

      {/* Mobile Sidebar Overlay */}
      {isMobile && sidebarOpen && (
        <>
          <div className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="fixed inset-y-0 left-0 z-50 w-64 bg-sidebar border-r border-sidebar-border flex flex-col animate-in slide-in-from-left duration-300">
            {sidebarContent}
          </aside>
        </>
      )}

      {/* Main content */}
      <main className="flex-1 overflow-y-auto min-w-0">
        {/* Top bar */}
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            {isMobile && (
              <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg hover:bg-secondary transition-colors shrink-0">
                <Menu className="w-5 h-5 text-foreground" />
              </button>
            )}
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-display font-semibold text-foreground truncate">
                {navItems.find(n => n.to === location.pathname)?.label || 'Dashboard'}
              </h2>
              <p className="text-xs text-muted-foreground hidden sm:block">
                Last updated: {new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button className="relative p-2 rounded-lg hover:bg-secondary transition-colors">
              <Bell className="w-4 sm:w-4.5 h-4 sm:h-4.5 text-muted-foreground" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-destructive" />
            </button>
            <div className="flex items-center gap-2 px-2 sm:px-3 py-1.5 rounded-lg bg-secondary text-xs">
              <Wifi className="w-3.5 h-3.5 text-primary" />
              <span className="text-secondary-foreground hidden sm:inline">Connected</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <div className="p-3 sm:p-4 md:p-6" style={{ background: 'var(--gradient-glow)' }}>
          {children}
        </div>
      </main>
    </div>
  );
}
