import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon: LucideIcon;
  trend?: { value: number; label: string };
  status?: 'good' | 'warning' | 'critical';
}

const statusStyles = {
  good: 'border-l-success',
  warning: 'border-l-warning',
  critical: 'border-l-destructive',
};

export function StatCard({ title, value, unit, icon: Icon, trend, status = 'good' }: StatCardProps) {
  return (
    <div className={`glass-card p-3 sm:p-5 border-l-4 ${statusStyles[status]} fade-in`}>
      <div className="flex items-start justify-between">
        <div className="space-y-1 min-w-0">
          <p className="text-xs sm:text-sm text-muted-foreground truncate">{title}</p>
          <div className="flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-display font-bold text-foreground">{value}</span>
            {unit && <span className="text-xs sm:text-sm text-muted-foreground">{unit}</span>}
          </div>
          {trend && (
            <p className={`text-xs ${trend.value >= 0 ? 'text-success' : 'text-destructive'}`}>
              {trend.value >= 0 ? '↑' : '↓'} {Math.abs(trend.value)}% {trend.label}
            </p>
          )}
        </div>
        <div className="p-2.5 rounded-lg bg-primary/10">
          <Icon className="w-5 h-5 text-primary" />
        </div>
      </div>
    </div>
  );
}
