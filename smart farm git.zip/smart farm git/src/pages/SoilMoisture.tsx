import { Sprout, Thermometer } from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import { TrendChart } from '@/components/dashboard/TrendChart';
import { GaugeMeter } from '@/components/dashboard/GaugeMeter';
import { AlertsPanel } from '@/components/dashboard/AlertsPanel';
import { currentReadings, soilData, recentAlerts, getMoistureStatus } from '@/lib/mockData';

const SoilMoisturePage = () => {
  const moisture = currentReadings.soil.moisture;
  const moistureStatus = getMoistureStatus(moisture);
  const soilAlerts = recentAlerts.filter(a => a.sensor === 'soil');

  return (
    <div className="space-y-6 fade-in">
      {/* Header */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="glass-card p-6 flex flex-col items-center justify-center">
          <GaugeMeter
            value={moisture}
            min={0}
            max={100}
            label="Soil Moisture"
            unit="%"
            status={moistureStatus.label === 'Optimal' ? 'good' : moistureStatus.label === 'Acceptable' ? 'warning' : 'critical'}
            size="lg"
          />
          <span className={`mt-2 text-sm font-medium ${moistureStatus.color}`}>{moistureStatus.label}</span>
        </div>
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <StatCard title="Soil Moisture" value={moisture} unit="%" icon={Sprout}
            status={moistureStatus.label === 'Optimal' ? 'good' : moistureStatus.label === 'Acceptable' ? 'warning' : 'critical'}
            trend={{ value: -5.2, label: 'vs 1h ago' }} />
          <StatCard title="Soil Temperature" value={currentReadings.soil.soilTemp} unit="°C" icon={Thermometer}
            status="good" trend={{ value: 1.1, label: 'vs 1h ago' }} />
        </div>
      </div>

      {/* Sensor info */}
      <div className="glass-card p-4">
        <h3 className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wider">Sensor Details</h3>
        <div className="p-2 rounded bg-secondary/30 text-xs flex justify-between">
          <span className="text-muted-foreground">Soil Sensor</span>
          <span className="text-foreground font-medium">Capacitive Soil Moisture Sensor v1.2 (0-100%)</span>
        </div>
      </div>

      {/* Moisture level bar */}
      <div className="glass-card p-4">
        <h3 className="text-sm font-medium text-muted-foreground mb-3">Moisture Level</h3>
        <div className="relative h-6 rounded-full bg-secondary overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-1000"
            style={{
              width: `${moisture}%`,
              background: moisture >= 40 && moisture <= 70
                ? 'linear-gradient(90deg, hsl(152,60%,32%), hsl(152,60%,42%))'
                : moisture >= 25
                ? 'linear-gradient(90deg, hsl(38,80%,40%), hsl(38,92%,50%))'
                : 'linear-gradient(90deg, hsl(0,60%,40%), hsl(0,72%,51%))',
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground">
            {moisture}%
          </div>
        </div>
        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
          <span>Dry (0%)</span>
          <span>Optimal (40-70%)</span>
          <span>Saturated (100%)</span>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <TrendChart data={soilData.moisture} title="Soil Moisture (24h)" color="green" unit="%" height={250} />
        <TrendChart data={soilData.soilTemp} title="Soil Temperature (24h)" color="amber" unit="°C" height={250} />
      </div>

      {/* Alerts */}
      <AlertsPanel alerts={soilAlerts} title="Soil Moisture Alerts" />
    </div>
  );
};

export default SoilMoisturePage;
