import { Wind, Thermometer, Droplets, Flame, Activity } from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import { TrendChart } from '@/components/dashboard/TrendChart';
import { GaugeMeter } from '@/components/dashboard/GaugeMeter';
import { AlertsPanel } from '@/components/dashboard/AlertsPanel';
import { currentReadings, airData, recentAlerts, getAqiStatus } from '@/lib/mockData';

const AirQualityPage = () => {
  const aqi = currentReadings.air.aqi;
  const aqiStatus = getAqiStatus(aqi);
  const airAlerts = recentAlerts.filter(a => a.sensor === 'air');

  return (
    <div className="space-y-6 fade-in">
      {/* Header with AQI Gauge */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="glass-card p-6 flex flex-col items-center justify-center glow-green">
          <GaugeMeter
            value={aqi}
            min={0}
            max={300}
            label="Air Quality Index"
            unit="AQI"
            status={aqiStatus.label === 'Good' ? 'good' : aqiStatus.label === 'Moderate' ? 'warning' : 'critical'}
            size="lg"
          />
          <span className={`mt-2 text-sm font-medium ${aqiStatus.color}`}>{aqiStatus.label}</span>
        </div>

        <div className="lg:col-span-2 grid grid-cols-2 gap-4">
          <StatCard title="CO₂ Level" value={currentReadings.air.co2} unit="ppm" icon={Activity}
            status={currentReadings.air.co2 > 500 ? 'warning' : 'good'}
            trend={{ value: 5.3, label: 'vs 1h ago' }} />
          <StatCard title="Temperature" value={currentReadings.air.temperature} unit="°C" icon={Thermometer}
            status="good" trend={{ value: -1.2, label: 'vs 1h ago' }} />
          <StatCard title="Humidity" value={currentReadings.air.humidity} unit="%" icon={Droplets}
            status={currentReadings.air.humidity > 80 ? 'warning' : 'good'}
            trend={{ value: 2.1, label: 'vs 1h ago' }} />
          <StatCard title="Smoke Level" value={currentReadings.air.smoke} unit="ppm" icon={Flame}
            status={currentReadings.air.smoke > 30 ? 'critical' : 'good'}
            trend={{ value: -3.4, label: 'vs 1h ago' }} />
        </div>
      </div>

      {/* Sensor info */}
      <div className="glass-card p-4">
        <h3 className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wider">Sensor Details</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="flex justify-between p-2 rounded bg-secondary/30">
            <span className="text-muted-foreground">Gas Sensor</span>
            <span className="text-foreground font-medium">MQ-135 (CO₂, NH₃, Smoke, Benzene)</span>
          </div>
          <div className="flex justify-between p-2 rounded bg-secondary/30">
            <span className="text-muted-foreground">Temp/Humidity</span>
            <span className="text-foreground font-medium">DHT22 (±0.5°C, ±2% RH)</span>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <TrendChart data={airData.co2} title="CO₂ Level (24h)" color="green" unit="ppm" height={220} />
        <TrendChart data={airData.temperature} title="Temperature (24h)" color="blue" unit="°C" height={220} />
        <TrendChart data={airData.humidity} title="Humidity (24h)" color="amber" unit="%" height={220} />
        <TrendChart data={airData.smoke} title="Smoke Level (24h)" color="red" unit="ppm" height={220} />
      </div>

      {/* AQI Trend + Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <TrendChart data={airData.aqi} title="AQI Trend (24h)" color="green" unit="AQI" height={220} />
        </div>
        <AlertsPanel alerts={airAlerts} title="Air Quality Alerts" />
      </div>
    </div>
  );
};

export default AirQualityPage;
