import { Droplets, Thermometer, Activity } from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import { TrendChart } from '@/components/dashboard/TrendChart';
import { GaugeMeter } from '@/components/dashboard/GaugeMeter';
import { AlertsPanel } from '@/components/dashboard/AlertsPanel';
import { currentReadings, waterData, recentAlerts, getPhStatus } from '@/lib/mockData';

const WaterQualityPage = () => {
  const ph = currentReadings.water.ph;
  const phStatus = getPhStatus(ph);
  const waterAlerts = recentAlerts.filter(a => a.sensor === 'water');

  return (
    <div className="space-y-6 fade-in">
      {/* Header */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="glass-card p-6 flex flex-col items-center justify-center">
          <GaugeMeter
            value={ph}
            min={0}
            max={14}
            label="Water pH Level"
            unit="pH"
            status={phStatus.label === 'Optimal' ? 'good' : phStatus.label === 'Acceptable' ? 'warning' : 'critical'}
            size="lg"
          />
          <span className={`mt-2 text-sm font-medium ${phStatus.color}`}>{phStatus.label}</span>
        </div>
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StatCard title="pH Level" value={ph} icon={Droplets}
            status={phStatus.label === 'Optimal' ? 'good' : 'warning'}
            trend={{ value: 0.3, label: 'vs 1h ago' }} />
          <StatCard title="TDS" value={currentReadings.water.tds} unit="ppm" icon={Activity}
            status="good" trend={{ value: -2.1, label: 'vs 1h ago' }} />
          <StatCard title="Water Temp" value={currentReadings.water.waterTemp} unit="°C" icon={Thermometer}
            status="good" trend={{ value: -0.5, label: 'vs 1h ago' }} />
        </div>
      </div>

      {/* Sensor info */}
      <div className="glass-card p-4">
        <h3 className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wider">Sensor Details</h3>
        <div className="p-2 rounded bg-secondary/30 text-xs flex justify-between">
          <span className="text-muted-foreground">pH Sensor Kit</span>
          <span className="text-foreground font-medium">Analog pH Meter (0-14 pH, ±0.1 accuracy)</span>
        </div>
      </div>

      {/* pH scale indicator */}
      <div className="glass-card p-4">
        <h3 className="text-sm font-medium text-muted-foreground mb-3">pH Scale</h3>
        <div className="relative h-8 rounded-full overflow-hidden" style={{
          background: 'linear-gradient(to right, hsl(0,72%,51%), hsl(38,92%,50%), hsl(60,80%,50%), hsl(120,60%,42%), hsl(199,89%,48%), hsl(240,60%,50%), hsl(280,65%,40%))'
        }}>
          <div className="absolute top-0 bottom-0 w-0.5 bg-foreground" style={{ left: `${(ph / 14) * 100}%` }}>
            <div className="absolute -top-5 left-1/2 -translate-x-1/2 text-xs font-bold text-foreground bg-card px-1.5 py-0.5 rounded">
              {ph}
            </div>
          </div>
        </div>
        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
          <span>Acidic (0)</span>
          <span>Neutral (7)</span>
          <span>Alkaline (14)</span>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <TrendChart data={waterData.ph} title="pH Level (24h)" color="blue" unit="pH" height={250} />
        <TrendChart data={waterData.tds} title="TDS Level (24h)" color="green" unit="ppm" height={250} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <TrendChart data={waterData.waterTemp} title="Water Temperature (24h)" color="amber" unit="°C" height={220} />
        </div>
        <AlertsPanel alerts={waterAlerts} title="Water Quality Alerts" />
      </div>
    </div>
  );
};

export default WaterQualityPage;
