import { Wind, Thermometer, Droplets, Gauge, Activity } from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import { TrendChart } from '@/components/dashboard/TrendChart';
import { AlertsPanel } from '@/components/dashboard/AlertsPanel';
import { LocationMap } from '@/components/dashboard/LocationMap';
import { currentReadings, airData, waterData, soilData, recentAlerts, getAqiStatus, getPhStatus, getMoistureStatus } from '@/lib/mockData';

const Index = () => {
  const aqiStatus = getAqiStatus(currentReadings.air.aqi);
  const phStatus = getPhStatus(currentReadings.water.ph);
  const moistureStatus = getMoistureStatus(currentReadings.soil.moisture);

  return (
    <div className="space-y-6 fade-in">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Air Quality Index"
          value={currentReadings.air.aqi}
          unit="AQI"
          icon={Wind}
          status={aqiStatus.label === 'Good' ? 'good' : aqiStatus.label === 'Moderate' ? 'warning' : 'critical'}
          trend={{ value: 3.2, label: 'vs last hour' }}
        />
        <StatCard
          title="Temperature"
          value={currentReadings.air.temperature}
          unit="°C"
          icon={Thermometer}
          status="good"
          trend={{ value: -1.5, label: 'vs last hour' }}
        />
        <StatCard
          title="Water pH"
          value={currentReadings.water.ph}
          icon={Droplets}
          status={phStatus.label === 'Optimal' ? 'good' : phStatus.label === 'Acceptable' ? 'warning' : 'critical'}
          trend={{ value: 0.8, label: 'vs last hour' }}
        />
        <StatCard
          title="Soil Moisture"
          value={currentReadings.soil.moisture}
          unit="%"
          icon={Gauge}
          status={moistureStatus.label === 'Optimal' ? 'good' : moistureStatus.label === 'Acceptable' ? 'warning' : 'critical'}
          trend={{ value: -5.2, label: 'vs last hour' }}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <TrendChart data={airData.aqi} title="Air Quality (24h)" color="green" unit="AQI" />
        <TrendChart data={waterData.ph} title="Water pH (24h)" color="blue" unit="pH" />
        <TrendChart data={soilData.moisture} title="Soil Moisture (24h)" color="amber" unit="%" />
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <AlertsPanel alerts={recentAlerts} />
        </div>
        <LocationMap />
      </div>

      {/* Latest Readings */}
      <div className="glass-card p-4 fade-in">
        <h3 className="text-sm font-medium text-muted-foreground mb-3">Latest Sensor Readings</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'CO₂', value: currentReadings.air.co2, unit: 'ppm' },
            { label: 'Humidity', value: currentReadings.air.humidity, unit: '%' },
            { label: 'Smoke', value: currentReadings.air.smoke, unit: 'ppm' },
            { label: 'NH₃', value: currentReadings.air.ammonia, unit: 'ppm' },
            { label: 'pH Level', value: currentReadings.water.ph, unit: '' },
            { label: 'TDS', value: currentReadings.water.tds, unit: 'ppm' },
            { label: 'Soil Moist.', value: currentReadings.soil.moisture, unit: '%' },
            { label: 'Soil Temp', value: currentReadings.soil.soilTemp, unit: '°C' },
          ].map(r => (
            <div key={r.label} className="text-center p-3 rounded-lg bg-secondary/50">
              <p className="text-xs text-muted-foreground mb-1">{r.label}</p>
              <p className="text-lg font-display font-bold text-foreground">{r.value}<span className="text-xs text-muted-foreground ml-0.5">{r.unit}</span></p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Index;
