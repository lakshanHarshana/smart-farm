// Mock data for the Smart Farm Monitoring Dashboard

export interface SensorReading {
  timestamp: string;
  value: number;
}

export interface Alert {
  id: string;
  type: 'warning' | 'critical' | 'info';
  sensor: 'air' | 'water' | 'soil';
  message: string;
  timestamp: string;
  value: number;
  threshold: number;
}

// Generate time series data for charts
function generateTimeSeries(hours: number, baseValue: number, variance: number, trend: number = 0): SensorReading[] {
  const data: SensorReading[] = [];
  const now = new Date();
  for (let i = hours; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 60 * 60 * 1000);
    const noise = (Math.random() - 0.5) * variance;
    const trendValue = trend * (hours - i) / hours;
    data.push({
      timestamp: time.toISOString(),
      value: Math.round((baseValue + noise + trendValue) * 10) / 10,
    });
  }
  return data;
}

// Air sensor data (MQ135 + DHT22)
export const airData = {
  co2: generateTimeSeries(24, 420, 80, 30),
  temperature: generateTimeSeries(24, 28, 5, -2),
  humidity: generateTimeSeries(24, 65, 15, 5),
  smoke: generateTimeSeries(24, 12, 8, 0),
  ammonia: generateTimeSeries(24, 8, 4, 1),
  aqi: generateTimeSeries(24, 72, 25, 10),
};

// Water sensor data (pH sensor)
export const waterData = {
  ph: generateTimeSeries(24, 6.8, 0.8, 0.2),
  tds: generateTimeSeries(24, 450, 100, -20),
  waterTemp: generateTimeSeries(24, 24, 3, -1),
};

// Soil sensor data
export const soilData = {
  moisture: generateTimeSeries(24, 55, 15, -8),
  soilTemp: generateTimeSeries(24, 22, 4, 1),
};

// Current readings (latest values)
export const currentReadings = {
  air: {
    co2: 448,
    temperature: 27.3,
    humidity: 68,
    smoke: 14,
    ammonia: 9.2,
    aqi: 78,
  },
  water: {
    ph: 7.1,
    tds: 432,
    waterTemp: 23.5,
  },
  soil: {
    moisture: 48,
    soilTemp: 22.8,
  },
};

// Recent alerts
export const recentAlerts: Alert[] = [
  {
    id: '1',
    type: 'critical',
    sensor: 'soil',
    message: 'Soil moisture critically low in Zone A',
    timestamp: new Date(Date.now() - 15 * 60000).toISOString(),
    value: 22,
    threshold: 30,
  },
  {
    id: '2',
    type: 'warning',
    sensor: 'air',
    message: 'CO₂ levels rising above normal range',
    timestamp: new Date(Date.now() - 45 * 60000).toISOString(),
    value: 520,
    threshold: 500,
  },
  {
    id: '3',
    type: 'warning',
    sensor: 'water',
    message: 'pH level slightly acidic in Tank B',
    timestamp: new Date(Date.now() - 2 * 3600000).toISOString(),
    value: 5.8,
    threshold: 6.0,
  },
  {
    id: '4',
    type: 'info',
    sensor: 'air',
    message: 'Temperature returned to normal range',
    timestamp: new Date(Date.now() - 3 * 3600000).toISOString(),
    value: 28,
    threshold: 35,
  },
  {
    id: '5',
    type: 'critical',
    sensor: 'water',
    message: 'Water pH dangerously high in Tank A',
    timestamp: new Date(Date.now() - 5 * 3600000).toISOString(),
    value: 9.2,
    threshold: 8.5,
  },
];

// Sensor device info
export const devices = [
  { id: 'esp32-001', name: 'Field Station Alpha', location: 'Zone A - North Field', status: 'online' as const, lastSeen: new Date(Date.now() - 30000).toISOString() },
  { id: 'esp32-002', name: 'Field Station Beta', location: 'Zone B - Greenhouse', status: 'online' as const, lastSeen: new Date(Date.now() - 60000).toISOString() },
  { id: 'esp32-003', name: 'Water Station 1', location: 'Irrigation Tank A', status: 'online' as const, lastSeen: new Date(Date.now() - 120000).toISOString() },
  { id: 'esp32-004', name: 'Field Station Gamma', location: 'Zone C - South Field', status: 'offline' as const, lastSeen: new Date(Date.now() - 3600000).toISOString() },
];

// Format helpers
export function formatTime(isoString: string): string {
  return new Date(isoString).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

export function formatTimeAgo(isoString: string): string {
  const diff = Date.now() - new Date(isoString).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export function getAqiStatus(aqi: number): { label: string; color: string } {
  if (aqi <= 50) return { label: 'Good', color: 'text-success' };
  if (aqi <= 100) return { label: 'Moderate', color: 'text-warning' };
  if (aqi <= 150) return { label: 'Unhealthy (Sensitive)', color: 'text-warning' };
  return { label: 'Unhealthy', color: 'text-destructive' };
}

export function getPhStatus(ph: number): { label: string; color: string } {
  if (ph >= 6.5 && ph <= 7.5) return { label: 'Optimal', color: 'text-success' };
  if (ph >= 6.0 && ph <= 8.0) return { label: 'Acceptable', color: 'text-warning' };
  return { label: 'Critical', color: 'text-destructive' };
}

export function getMoistureStatus(moisture: number): { label: string; color: string } {
  if (moisture >= 40 && moisture <= 70) return { label: 'Optimal', color: 'text-success' };
  if (moisture >= 25 && moisture <= 85) return { label: 'Acceptable', color: 'text-warning' };
  return { label: 'Critical', color: 'text-destructive' };
}
