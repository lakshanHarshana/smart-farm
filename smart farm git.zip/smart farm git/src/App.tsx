import { useState, useEffect, useRef } from "react";

function useSpring(target, dec = 1) {
  const [val, setVal] = useState(target);
  const cur = useRef(target);
  useEffect(() => {
    const from = cur.current, to = target, dur = 900, t0 = performance.now();
    const go = (now) => {
      const p = Math.min((now - t0) / dur, 1);
      const e = 1 - Math.pow(1 - p, 4);
      const v = from + (to - from) * e;
      cur.current = v;
      setVal(parseFloat(v.toFixed(dec)));
      if (p < 1) requestAnimationFrame(go);
    };
    requestAnimationFrame(go);
  }, [target]);
  return val;
}

function Particles() {
  const ref = useRef();
  useEffect(() => {
    const c = ref.current, ctx = c.getContext("2d");
    const resize = () => { c.width = window.innerWidth; c.height = window.innerHeight; };
    resize(); window.addEventListener("resize", resize);
    const P = Array.from({ length: 90 }, () => ({
      x: Math.random() * c.width, y: Math.random() * c.height,
      r: Math.random() * 2 + 0.3, vx: (Math.random() - .5) * .25, vy: -(Math.random() * .5 + .1),
      a: Math.random() * .6 + .1, h: Math.random() * 80 + 100,
    }));
    let raf;
    const draw = () => {
      ctx.clearRect(0, 0, c.width, c.height);
      P.forEach(p => {
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.h},90%,65%,${p.a})`; ctx.fill();
        p.x += p.vx; p.y += p.vy;
        if (p.y < -10) { p.y = c.height + 10; p.x = Math.random() * c.width; }
        if (p.x < 0 || p.x > c.width) p.vx *= -1;
      });
      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);
  return <canvas ref={ref} style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", opacity: .45 }} />;
}

function AirTempCard({ value }) {
  const v = useSpring(value, 1);
  const pct = Math.min((value - 10) / 40, 1);
  const color = value > 32 ? "#ff4d6d" : value > 25 ? "#ff9f43" : "#00e5c8";
  return (
    <div className="scard" style={{ "--accent": color, background: "linear-gradient(145deg,#0d1b14,#162010)" }}>
      <div className="scard-label">TEMPERATURE</div>
      <div style={{ position:"absolute", top:18, right:18, fontSize:28 }}>🌡️</div>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:20, flex:1, marginTop:8 }}>
        <div style={{ position:"relative", width:26, height:110 }}>
          <div style={{ position:"absolute", left:7, top:0, width:12, height:82, borderRadius:"6px 6px 0 0", background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.1)", overflow:"hidden" }}>
            <div style={{ position:"absolute", bottom:0, left:0, right:0, background:`linear-gradient(0deg,${color},${color}88)`, height:`${pct*100}%`, transition:"height 1s ease", boxShadow:`0 0 10px ${color}` }}/>
          </div>
          <div style={{ position:"absolute", bottom:0, left:0, width:26, height:26, borderRadius:"50%", background:`radial-gradient(circle,${color},${color}88)`, boxShadow:`0 0 16px ${color}`, border:`2px solid ${color}` }}/>
        </div>
        <div>
          <div style={{ fontFamily:"'Orbitron',monospace", fontSize:50, fontWeight:900, color, lineHeight:1, textShadow:`0 0 30px ${color}88` }}>{v}°</div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,.35)", marginTop:4, letterSpacing:".05em" }}>CELSIUS</div>
        </div>
      </div>
      <div className="scard-bar-row">
        <div className="scard-bar-bg"><div className="scard-bar-fill" style={{ width:`${pct*100}%`, background:`linear-gradient(90deg,${color}66,${color})` }}/></div>
        <span className="scard-range">10–50°C</span>
      </div>
    </div>
  );
}

function HumidityCard({ value }) {
  const v = useSpring(value, 1);
  const pct = value / 100;
  const color = "#38bdf8";
  const waveRef = useRef();
  useEffect(() => {
    let t = 0, raf;
    const c = waveRef.current; if (!c) return;
    const ctx = c.getContext("2d");
    c.width = 200; c.height = 90;
    const W = c.width, H = c.height;
    const animate = () => {
      ctx.clearRect(0, 0, W, H);
      const fillY = H * (1 - pct);
      ctx.beginPath(); ctx.moveTo(0, fillY);
      for (let x = 0; x <= W; x++) {
        const y = fillY + Math.sin((x/W)*Math.PI*4 + t)*5 + Math.sin((x/W)*Math.PI*2 + t*1.3)*3;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(W,H); ctx.lineTo(0,H); ctx.closePath();
      const g = ctx.createLinearGradient(0,0,0,H);
      g.addColorStop(0, `${color}cc`); g.addColorStop(1, `${color}44`);
      ctx.fillStyle = g; ctx.fill();
      t += 0.04; raf = requestAnimationFrame(animate);
    };
    animate();
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return (
    <div className="scard" style={{ "--accent":color, background:"linear-gradient(145deg,#0a1520,#0d1e2e)" }}>
      <div className="scard-label">HUMIDITY</div>
      <div style={{ position:"absolute", top:18, right:18, fontSize:28 }}>💧</div>
      <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:8 }}>
        <div style={{ position:"relative", width:90, height:110 }}>
          <svg viewBox="0 0 100 120" style={{ width:"100%", height:"100%", position:"absolute", inset:0 }}>
            <defs>
              <clipPath id="dc"><path d="M50 8 C50 8 12 58 12 82 A38 38 0 0 0 88 82 C88 58 50 8 50 8Z"/></clipPath>
            </defs>
            <path d="M50 8 C50 8 12 58 12 82 A38 38 0 0 0 88 82 C88 58 50 8 50 8Z" fill={`${color}15`} stroke={color} strokeWidth="1.5" style={{filter:`drop-shadow(0 0 14px ${color})`}}/>
            <rect x="12" y={8+(1-pct)*112} width="76" height="120" clipPath="url(#dc)" fill={`${color}77`} style={{transition:"y 1s ease"}}/>
          </svg>
          <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", paddingTop:25 }}>
            <span style={{ fontFamily:"'Orbitron',monospace", fontSize:20, fontWeight:900, color, textShadow:`0 0 12px ${color}` }}>{v}%</span>
          </div>
        </div>
        <canvas ref={waveRef} style={{ width:"100%", height:50, borderRadius:10, opacity:.85 }}/>
      </div>
    </div>
  );
}

function WaterTempCard({ value }) {
  const v = useSpring(value, 1);
  const color = "#00e5c8";
  return (
    <div className="scard" style={{ "--accent":color, background:"linear-gradient(145deg,#071a18,#0c2420)" }}>
      <div className="scard-label">WATER TEMP</div>
      <div style={{ position:"absolute", top:18, right:18, fontSize:28 }}>🌊</div>
      <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
        {[0,1,2,3].map(i=>(
          <div key={i} style={{
            position:"absolute", borderRadius:"50%", border:`1.5px solid ${color}`,
            animation:`ripple 2.8s ${i*.7}s ease-out infinite`,
          }}/>
        ))}
        <div style={{
          width:96, height:96, borderRadius:"50%",
          background:`radial-gradient(circle,${color}1a,${color}06)`,
          border:`2px solid ${color}`, boxShadow:`0 0 30px ${color}44, inset 0 0 20px ${color}11`,
          display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", zIndex:2,
          position:"relative"
        }}>
          <div style={{ fontFamily:"'Orbitron',monospace", fontSize:28, fontWeight:900, color, lineHeight:1 }}>{v}°</div>
          <div style={{ fontSize:9, color:`${color}88`, letterSpacing:".12em", marginTop:2 }}>WATER</div>
        </div>
      </div>
      <div className="scard-bar-row">
        <div className="scard-bar-bg"><div className="scard-bar-fill" style={{ width:`${(value/40)*100}%`, background:`linear-gradient(90deg,${color}55,${color})` }}/></div>
        <span className="scard-range">0–40°C</span>
      </div>
    </div>
  );
}

function SoilCard({ value, zone, color, icon }) {
  const v = useSpring(value, 0);
  const radius = 50, stroke = 10, circ = 2*Math.PI*radius;
  const dash = (value/100)*circ;
  const status = value < 30 ? {t:"DRY",c:"#ff4d6d"} : value > 75 ? {t:"WET",c:"#38bdf8"} : {t:"IDEAL",c:"#00ff87"};
  return (
    <div className="scard" style={{ "--accent":color, background:"linear-gradient(145deg,#0d1a0a,#152210)" }}>
      <div className="scard-label">SOIL · {zone.toUpperCase()}</div>
      <div style={{ position:"absolute", top:18, right:18, fontSize:28 }}>{icon}</div>
      <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:10 }}>
        <div style={{ position:"relative", width:120, height:120 }}>
          <svg width={120} height={120} style={{ transform:"rotate(-90deg)" }}>
            {Array.from({length:24}).map((_,i)=>{
              const a=(i/24)*2*Math.PI-Math.PI/2;
              return <circle key={i} cx={60+radius*Math.cos(a)} cy={60+radius*Math.sin(a)} r={2.5} fill={`${color}22`}/>;
            })}
            <circle cx={60} cy={60} r={radius} fill="none" stroke={`${color}12`} strokeWidth={stroke}/>
            <circle cx={60} cy={60} r={radius} fill="none" stroke={color} strokeWidth={stroke}
              strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
              style={{transition:"stroke-dasharray 1s ease",filter:`drop-shadow(0 0 8px ${color})`}}/>
          </svg>
          <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
            <div style={{ fontFamily:"'Orbitron',monospace", fontSize:28, fontWeight:900, color, lineHeight:1 }}>{v}%</div>
            <div style={{ fontSize:9, fontWeight:700, color:status.c, letterSpacing:".12em", marginTop:4, padding:"2px 8px", borderRadius:10, background:`${status.c}22`, border:`1px solid ${status.c}44` }}>{status.t}</div>
          </div>
        </div>
        <div style={{ width:"100%", height:16, borderRadius:8, overflow:"hidden", background:"rgba(255,255,255,.04)", border:"1px solid rgba(255,255,255,.07)", position:"relative" }}>
          <div style={{ height:"100%", width:`${value}%`, background:`linear-gradient(90deg,${color}44,${color})`, transition:"width 1s ease" }}>
            {Array.from({length:6}).map((_,i)=>(
              <div key={i} style={{ position:"absolute", width:4, height:4, borderRadius:"50%", background:`${color}88`, top:"50%", transform:"translateY(-50%)", left:`${10+i*15}%` }}/>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function PhCard({ value }) {
  const v = useSpring(value, 1);
  const pct = value / 14;
  const hue = pct * 270;
  const color = `hsl(${hue},90%,65%)`;
  const label = value < 6 ? "ACIDIC" : value > 7.5 ? "ALKALINE" : "NEUTRAL";
  const lcolor = value < 6 ? "#ff6b6b" : value > 7.5 ? "#a78bfa" : "#00ff87";
  return (
    <div className="scard" style={{ "--accent":color, background:"linear-gradient(145deg,#15100d,#1e1508)" }}>
      <div className="scard-label">pH LEVEL</div>
      <div style={{ position:"absolute", top:18, right:18, fontSize:28 }}>⚗️</div>
      <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:14 }}>
        <div style={{ width:"100%", height:12, borderRadius:6, background:"linear-gradient(90deg,#ff0000,#ff7700,#ffff00,#00ff00,#0077ff,#8800ff)", position:"relative", boxShadow:"0 0 20px rgba(255,255,255,.1)", border:"1px solid rgba(255,255,255,.08)" }}>
          <div style={{
            position:"absolute", top:"50%", transform:"translate(-50%,-50%)",
            left:`${pct*100}%`, width:14, height:26, background:"white",
            borderRadius:3, boxShadow:`0 0 14px ${color}, 0 0 4px white`,
            transition:"left 1s ease"
          }}/>
          {[0,2,4,6,7,8,10,12,14].map(n=>(
            <div key={n} style={{
              position:"absolute", bottom:-14, left:`${(n/14)*100}%`, transform:"translateX(-50%)",
              fontSize:7, color:"rgba(255,255,255,.3)", fontFamily:"'Orbitron',monospace"
            }}>{n}</div>
          ))}
        </div>
        <div style={{ textAlign:"center", marginTop:18 }}>
          <div style={{ fontFamily:"'Orbitron',monospace", fontSize:56, fontWeight:900, color, lineHeight:1, textShadow:`0 0 40px ${color}88` }}>{v}</div>
          <div style={{ fontSize:11, fontWeight:700, color:lcolor, letterSpacing:".2em", marginTop:10, padding:"4px 16px", borderRadius:12, background:`${lcolor}22`, border:`1px solid ${lcolor}44`, display:"inline-block" }}>{label}</div>
        </div>
      </div>
    </div>
  );
}

function TurbidityCard({ value }) {
  const v = useSpring(value, 1);
  const canRef = useRef();
  const color = "#c084fc";
  useEffect(() => {
    const c = canRef.current; if (!c) return;
    const ctx = c.getContext("2d");
    const W = c.width = 200, H = c.height = 100;
    let raf;
    const dots = Array.from({ length: Math.round(value*1.2+8) }, () => ({
      x:Math.random()*W, y:Math.random()*H, r:Math.random()*3+1,
      vx:(Math.random()-.5)*.5, vy:(Math.random()-.5)*.5,
    }));
    const draw = () => {
      ctx.clearRect(0,0,W,H);
      const g=ctx.createLinearGradient(0,0,0,H);
      g.addColorStop(0,`rgba(192,132,252,${value/300})`);
      g.addColorStop(1,`rgba(192,132,252,${value/150})`);
      ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
      dots.forEach(d=>{
        ctx.beginPath(); ctx.arc(d.x,d.y,d.r,0,Math.PI*2);
        ctx.fillStyle=`rgba(192,132,252,${.3+value/200})`; ctx.fill();
        d.x+=d.vx; d.y+=d.vy;
        if(d.x<0||d.x>W)d.vx*=-1;
        if(d.y<0||d.y>H)d.vy*=-1;
      });
      raf=requestAnimationFrame(draw);
    };
    draw(); return () => cancelAnimationFrame(raf);
  }, [value]);
  const clarity = value<20?{t:"CRYSTAL CLEAR",c:"#00ff87"}:value<50?{t:"CLOUDY",c:"#f5c842"}:{t:"MURKY",c:"#ff4d6d"};
  return (
    <div className="scard" style={{ "--accent":color, background:"linear-gradient(145deg,#120d1a,#1a1025)" }}>
      <div className="scard-label">TURBIDITY</div>
      <div style={{ position:"absolute", top:18, right:18, fontSize:28 }}>🔬</div>
      <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:12 }}>
        <div style={{ position:"relative", borderRadius:14, overflow:"hidden", width:"100%", height:90, border:`1px solid ${color}33` }}>
          <canvas ref={canRef} style={{ width:"100%", height:"100%", display:"block" }}/>
          <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center" }}>
            <div style={{ fontFamily:"'Orbitron',monospace", fontSize:34, fontWeight:900, color, textShadow:`0 0 20px ${color}` }}>{v}%</div>
          </div>
        </div>
        <div style={{ fontSize:10, fontWeight:700, color:clarity.c, letterSpacing:".18em", padding:"4px 14px", borderRadius:12, background:`${clarity.c}22`, border:`1px solid ${clarity.c}44` }}>{clarity.t}</div>
      </div>
    </div>
  );
}

function MiniSpark({ data, color }) {
  if (!data||data.length<2) return <div style={{height:36}}/>;
  const W=160,H=36,min=Math.min(...data),max=Math.max(...data),range=max-min||1;
  const pts=data.map((v,i)=>`${(i/(data.length-1))*W},${H-((v-min)/range)*(H-6)-3}`).join(" ");
  return (
    <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} style={{overflow:"visible"}}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{filter:`drop-shadow(0 0 3px ${color})`}}/>
    </svg>
  );
}

export default function AgroSense() {
  const [nav, setNav] = useState("Dashboard");
  const [data, setData] = useState({ Air_Temp:28.4, Humidity:65.2, Water_Temp:22.1, Soil_Moisture_1:58, Soil_Moisture_2:71, pH_Level:6.8, Turbidity:12.3 });
  const [history, setHistory] = useState({ Air_Temp:[26,27,27.5,28,28.4], Humidity:[60,62,64,65,65.2], Water_Temp:[21,21.5,22,22,22.1], Soil_Moisture_1:[50,53,55,57,58], Soil_Moisture_2:[65,67,69,70,71], pH_Level:[6.5,6.6,6.7,6.8,6.8], Turbidity:[10,11,11.5,12,12.3] });
  const [time, setTime] = useState(new Date());
  const [connected, setConnected] = useState(false);

  useEffect(()=>{ const t=setInterval(()=>setTime(new Date()),1000); return ()=>clearInterval(t); },[]);

  useEffect(()=>{
    try {
      if (typeof firebase !== "undefined") {
        if (!firebase.apps.length) firebase.initializeApp({
          apiKey:"AIzaSyCNaIfSyOwcd-2K_iuUwKrRoTgeH5SknWA",
          authDomain:"smart-farm-69f27.firebaseapp.com",
          databaseURL:"https://smart-farm-69f27-default-rtdb.firebaseio.com",
          projectId:"smart-farm-69f27",
        });
        firebase.database().ref("/SensorLog").on("value", s=>{
          const v=s.val(); if(!v) return;
          setData(v); setConnected(true);
          setHistory(h=>{const n={};Object.keys(v).forEach(k=>{n[k]=[...(h[k]||[]).slice(-29),v[k]];});return n;});
        }); return;
      }
    } catch(e) {}
    const iv=setInterval(()=>{
      setData(p=>{
        const n={
          Air_Temp:+(p.Air_Temp+(Math.random()-.5)*.5).toFixed(1),
          Humidity:+(Math.min(95,Math.max(20,p.Humidity+(Math.random()-.5)*1.5))).toFixed(1),
          Water_Temp:+(p.Water_Temp+(Math.random()-.5)*.3).toFixed(1),
          Soil_Moisture_1:Math.round(Math.min(100,Math.max(0,p.Soil_Moisture_1+(Math.random()-.5)*3))),
          Soil_Moisture_2:Math.round(Math.min(100,Math.max(0,p.Soil_Moisture_2+(Math.random()-.5)*3))),
          pH_Level:+(Math.min(9,Math.max(4,p.pH_Level+(Math.random()-.5)*.15))).toFixed(1),
          Turbidity:+(Math.min(100,Math.max(0,p.Turbidity+(Math.random()-.5)*2))).toFixed(1),
        };
        setHistory(h=>{const nh={};Object.keys(n).forEach(k=>{nh[k]=[...(h[k]||[]).slice(-29),n[k]];});return nh;});
        return n;
      });
    }, 5000);
    return ()=>clearInterval(iv);
  },[]);

  const navItems=["Dashboard","Analytics","Controls","Alerts","Settings"];
  const overallHealth=Math.round([
    data.Humidity>40&&data.Humidity<80?100:40,
    data.pH_Level>5.5&&data.pH_Level<7.5?100:40,
    data.Soil_Moisture_1>30&&data.Soil_Moisture_1<80?100:40,
    data.Turbidity<40?100:40,
  ].reduce((a,b)=>a+b,0)/4);

  return (
    <div style={{minHeight:"100vh",background:"#070e09",fontFamily:"'Syne',sans-serif",color:"#edf5ef",overflowX:"hidden"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Orbitron:wght@400;700;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-thumb{background:#00ff87;border-radius:2px}
        @keyframes fadeUp{from{opacity:0;transform:translateY(32px)}to{opacity:1;transform:translateY(0)}}
        @keyframes ripple{0%{width:60px;height:60px;opacity:.8;top:calc(50% - 30px);left:calc(50% - 30px)}100%{width:180px;height:180px;opacity:0;top:calc(50% - 90px);left:calc(50% - 90px)}}
        @keyframes glow-pulse{0%,100%{opacity:.6;box-shadow:0 0 6px currentColor}50%{opacity:1;box-shadow:0 0 18px currentColor}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes scan-h{0%{transform:translateX(-100%)}100%{transform:translateX(100vw)}}
        .scard{border-radius:22px;border:1px solid rgba(255,255,255,0.07);padding:22px 20px 18px;display:flex;flex-direction:column;gap:8px;position:relative;overflow:hidden;min-height:270px;transition:transform .3s ease,box-shadow .3s ease,border-color .3s ease;animation:fadeUp .7s ease both;}
        .scard::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,var(--accent,#00ff87),transparent);opacity:.4;}
        .scard:hover{transform:translateY(-7px) scale(1.02);box-shadow:0 24px 60px rgba(0,0,0,.5),0 0 0 1px var(--accent,#00ff87)33;}
        .scard-label{font-size:9px;font-weight:800;letter-spacing:.2em;color:rgba(255,255,255,.35);font-family:'Orbitron',monospace;}
        .scard-bar-bg{flex:1;height:4px;border-radius:2px;background:rgba(255,255,255,.07);overflow:hidden;}
        .scard-bar-fill{height:100%;border-radius:2px;transition:width 1s cubic-bezier(.4,0,.2,1);}
        .scard-bar-row{display:flex;align-items:center;gap:10;margin-top:auto;padding-top:10px;border-top:1px solid rgba(255,255,255,.05);}
        .scard-range{font-size:8px;color:rgba(255,255,255,.2);font-family:'Orbitron',monospace;white-space:nowrap;}
        .nav-link{cursor:pointer;padding:8px 18px;border-radius:30px;font-size:13px;font-weight:700;letter-spacing:.06em;transition:all .25s;color:rgba(232,245,236,.4);}
        .nav-link:hover{color:#00ff87;}
        .nav-link.on{color:#070e09;background:#00ff87;box-shadow:0 0 24px rgba(0,255,135,.5);}
      `}</style>

      <Particles/>
      <div style={{position:"fixed",top:0,left:0,width:"60%",height:"1.5px",background:"linear-gradient(90deg,transparent,#00ff87,transparent)",zIndex:50,pointerEvents:"none",animation:"scan-h 5s linear infinite",opacity:.5}}/>

      {/* NAV */}
      <nav style={{position:"sticky",top:0,zIndex:40,backdropFilter:"blur(30px)",background:"rgba(7,14,9,.9)",borderBottom:"1px solid rgba(0,255,135,.07)",height:68,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 32px",gap:20}}>
        <div style={{display:"flex",alignItems:"center",gap:14,flexShrink:0}}>
          <div style={{position:"relative",width:42,height:42}}>
            <div style={{width:42,height:42,borderRadius:"50%",border:"1.5px solid rgba(0,255,135,.3)",display:"flex",alignItems:"center",justifyContent:"center",animation:"spin 10s linear infinite",background:"rgba(0,255,135,.04)"}}>
              <span style={{fontSize:20}}>🌿</span>
            </div>
            <div style={{position:"absolute",width:8,height:8,borderRadius:"50%",background:"#00ff87",top:-2,right:-2,animation:"glow-pulse 1.5s infinite",color:"#00ff87"}}/>
          </div>
          <div>
            <div style={{fontFamily:"'Orbitron',monospace",fontWeight:900,fontSize:16,letterSpacing:".08em"}}>AGRO<span style={{color:"#00ff87"}}>SENSE</span></div>
            <div style={{fontSize:8,color:"rgba(255,255,255,.2)",letterSpacing:".25em",fontFamily:"'Orbitron',monospace"}}>SMART FARM OS v2.4</div>
          </div>
        </div>
        <div style={{display:"flex",gap:2}}>
          {navItems.map(n=><div key={n} className={`nav-link${nav===n?" on":""}`} onClick={()=>setNav(n)}>{n}</div>)}
        </div>
        <div style={{display:"flex",alignItems:"center",gap:16,flexShrink:0}}>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:18,fontWeight:700,color:"#00ff87",letterSpacing:".06em",textShadow:"0 0 20px rgba(0,255,135,.5)"}}>{time.toLocaleTimeString("en-US",{hour12:false})}</div>
          <div style={{display:"flex",alignItems:"center",gap:6,background:"rgba(0,255,135,.07)",border:"1px solid rgba(0,255,135,.15)",borderRadius:20,padding:"6px 14px"}}>
            <div style={{width:7,height:7,borderRadius:"50%",background:connected?"#00ff87":"#f5c842",animation:"glow-pulse 2s infinite",color:connected?"#00ff87":"#f5c842"}}/>
            <span style={{fontSize:10,fontFamily:"'Orbitron',monospace",color:connected?"#00ff87":"#f5c842",fontWeight:700}}>{connected?"FIREBASE LIVE":"SIMULATION"}</span>
          </div>
        </div>
      </nav>

      <main style={{position:"relative",zIndex:1,maxWidth:1440,margin:"0 auto",padding:"36px 32px"}}>
        {/* Hero */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:44,flexWrap:"wrap",gap:20,animation:"fadeUp .5s ease"}}>
          <div>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:10,letterSpacing:".4em",color:"rgba(0,255,135,.6)",marginBottom:8}}>REAL-TIME MONITORING</div>
            <h1 style={{fontSize:"clamp(28px,4vw,50px)",fontWeight:800,letterSpacing:"-.02em",lineHeight:1.08}}>
              Farm Intelligence<br/>
              <span style={{background:"linear-gradient(100deg,#00ff87 0%,#00e5c8 45%,#38bdf8 100%)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>Command Center</span>
            </h1>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:20}}>
            <div style={{position:"relative",width:100,height:100}}>
              <svg width={100} height={100} style={{transform:"rotate(-90deg)"}}>
                <circle cx={50} cy={50} r={40} fill="none" stroke="rgba(255,255,255,.06)" strokeWidth={8}/>
                <circle cx={50} cy={50} r={40} fill="none"
                  stroke={overallHealth>80?"#00ff87":overallHealth>50?"#f5c842":"#ff4d6d"}
                  strokeWidth={8} strokeLinecap="round"
                  strokeDasharray={`${(overallHealth/100)*251} 251`}
                  style={{transition:"stroke-dasharray 1s ease",filter:`drop-shadow(0 0 10px ${overallHealth>80?"#00ff87":overallHealth>50?"#f5c842":"#ff4d6d"})`}}/>
              </svg>
              <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                <span style={{fontFamily:"'Orbitron',monospace",fontSize:24,fontWeight:900,color:overallHealth>80?"#00ff87":overallHealth>50?"#f5c842":"#ff4d6d",lineHeight:1}}>{overallHealth}</span>
                <span style={{fontSize:8,color:"rgba(255,255,255,.3)",letterSpacing:".1em",fontFamily:"'Orbitron',monospace"}}>HEALTH</span>
              </div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {[{l:"Sensors",v:"7 / 7 ONLINE",c:"#00ff87"},{l:"Interval",v:"5 SEC LIVE",c:"#38bdf8"},{l:"Updated",v:time.toLocaleTimeString("en-US",{hour12:false}),c:"#c084fc"}].map(r=>(
                <div key={r.l} style={{fontSize:11}}>
                  <span style={{color:"rgba(255,255,255,.3)"}}>{r.l}: </span>
                  <span style={{fontFamily:"'Orbitron',monospace",fontWeight:700,color:r.c,fontSize:10}}>{r.v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* SENSOR GRID */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(210px,1fr))",gap:20,marginBottom:40}}>
          <div style={{animationDelay:"0s"}}><AirTempCard value={data.Air_Temp}/></div>
          <div style={{animationDelay:".07s"}}><HumidityCard value={data.Humidity}/></div>
          <div style={{animationDelay:".14s"}}><WaterTempCard value={data.Water_Temp}/></div>
          <div style={{animationDelay:".21s"}}><SoilCard value={data.Soil_Moisture_1} zone="Zone A" color="#00ff87" icon="🌱"/></div>
          <div style={{animationDelay:".28s"}}><SoilCard value={data.Soil_Moisture_2} zone="Zone B" color="#a3e635" icon="🌿"/></div>
          <div style={{animationDelay:".35s"}}><PhCard value={data.pH_Level}/></div>
          <div style={{animationDelay:".42s"}}><TurbidityCard value={data.Turbidity}/></div>
        </div>

        {/* TREND HISTORY */}
        <div style={{background:"linear-gradient(135deg,#0b1610,#0f1b12)",border:"1px solid rgba(0,255,135,.08)",borderRadius:22,padding:"28px",animation:"fadeUp .7s .5s ease both"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
            <div style={{fontWeight:800,fontSize:16}}>Sensor Trend History</div>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:9,color:"rgba(255,255,255,.2)",letterSpacing:".2em"}}>LAST {(history.Air_Temp||[]).length} READINGS · LIVE</div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))",gap:14}}>
            {[
              {key:"Air_Temp",label:"Air Temp",color:"#ff6b6b",unit:"°C"},
              {key:"Humidity",label:"Humidity",color:"#38bdf8",unit:"%"},
              {key:"Water_Temp",label:"Water",color:"#00e5c8",unit:"°C"},
              {key:"Soil_Moisture_1",label:"Soil A",color:"#00ff87",unit:"%"},
              {key:"Soil_Moisture_2",label:"Soil B",color:"#a3e635",unit:"%"},
              {key:"pH_Level",label:"pH",color:"#f5c842",unit:""},
              {key:"Turbidity",label:"Turbidity",color:"#c084fc",unit:"%"},
            ].map(s=>{
              const d=history[s.key]||[];
              const cur=d[d.length-1]||0, prev=d[d.length-2]||cur, delta=cur-prev;
              return (
                <div key={s.key} style={{background:"rgba(255,255,255,.02)",borderRadius:14,padding:"14px",border:"1px solid rgba(255,255,255,.04)"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                    <span style={{fontSize:10,color:"rgba(255,255,255,.4)",fontWeight:700,letterSpacing:".05em"}}>{s.label}</span>
                    <span style={{fontFamily:"'Orbitron',monospace",fontSize:9,fontWeight:700,color:delta>0?"#ff6b6b":delta<0?"#38bdf8":"#666"}}>
                      {delta>0?"▲":delta<0?"▼":"—"}{Math.abs(delta).toFixed(1)}{s.unit}
                    </span>
                  </div>
                  <MiniSpark data={d} color={s.color}/>
                  <div style={{fontFamily:"'Orbitron',monospace",fontSize:20,fontWeight:900,color:s.color,marginTop:6,lineHeight:1}}>{cur}{s.unit}</div>
                </div>
              );
            })}
          </div>
        </div>

        <div style={{textAlign:"center",marginTop:36,fontFamily:"'Orbitron',monospace",fontSize:9,letterSpacing:".3em",color:"rgba(255,255,255,.1)"}}>
          AGROSENSE SMART FARM OS · FIREBASE RTDB · ESP32 · 2025
        </div>
      </main>
    </div>
  );
}