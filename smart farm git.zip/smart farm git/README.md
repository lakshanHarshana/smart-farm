# 🌾 Green Monitor Hub - Smart Farm Monitoring System

**Production-Ready IoT Backend & React Frontend**

[![Status](https://img.shields.io/badge/Status-Production%20Ready-green)]() [![Version](https://img.shields.io/badge/Version-1.0.0-blue)]() [![License](https://img.shields.io/badge/License-MIT-green)]()

## 📋 Project Overview

Green Monitor Hub is a complete smart farm monitoring system combining:
- ✅ **Firebase Backend** - Cloud Functions for real-time sensor processing
- ✅ **React Frontend** - Modern dashboard for monitoring and control
- ✅ **ESP32 Devices** - IoT sensors for farms and greenhouses
- ✅ **Email Alerts** - Automated notifications for critical conditions
- ✅ **Automatic Control** - Smart pump and fan automation

## 🚀 Quick Start

### Setup in 5 Minutes

```bash
# 1. Clone the repository
git clone <YOUR_GIT_URL>
cd green-monitor-hub-main

# 2. Install dependencies (both frontend and backend)
npm install
cd functions && npm install && cd ..

# 3. Configure Firebase
cp functions/.env.example functions/.env
# Edit functions/.env with your Firebase credentials

# 4. Start development
npm run dev

# 5. Deploy backend (optional)
firebase deploy
```

## 📚 Documentation

**Start here:**
- [QUICKSTART.md](./QUICKSTART.md) - 5-minute setup guide
- [BACKEND_README.md](./BACKEND_README.md) - Backend overview

**Complete guides:**
- [DEPLOYMENT.md](./DEPLOYMENT.md) - Production deployment (600+ lines)
- [ARCHITECTURE.md](./ARCHITECTURE.md) - System design documentation (800+ lines)
- [ESP32_GUIDE.md](./ESP32_GUIDE.md) - ESP32 firmware guide (600+ lines)
- [FRONTEND_INTEGRATION.md](./FRONTEND_INTEGRATION.md) - React integration (500+ lines)
- [DOCUMENTATION.md](./DOCUMENTATION.md) - Complete documentation index

## 🏗️ Project Structure

```
green-monitor-hub-main/
├── src/                          # React Frontend
│   ├── components/               # Reusable React components
│   ├── pages/                    # Page components
│   ├── hooks/                    # Custom React hooks
│   ├── lib/                      # Utilities
│   └── App.tsx                   # Main app component
│
├── functions/                    # Firebase Cloud Functions Backend
│   ├── index.js                  # Main Cloud Function
│   ├── services/                 # Service layer
│   │   ├── processingService.js  # Sensor processing
│   │   ├── alertService.js       # Alert management
│   │   ├── controlService.js     # Pump/fan automation
│   │   └── emailService.js       # Email notifications
│   ├── utils/                    # Utilities
│   ├── package.json              # Backend dependencies
│   ├── database.rules.json       # Firebase security rules
│   └── .env.example              # Environment template
│
├── server/                       # Optional Node.js server
│
├── firebase.json                 # Firebase configuration
├── .firebaserc                   # Firebase project ID
│
├── QUICKSTART.md                 # Setup guide
├── DEPLOYMENT.md                 # Deployment guide
├── ARCHITECTURE.md               # Architecture documentation
├── ESP32_GUIDE.md                # Hardware guide with firmware
├── FRONTEND_INTEGRATION.md       # React integration guide
├── DOCUMENTATION.md              # Documentation index
└── package.json                  # Frontend dependencies
```

```

## ⚙️ Technology Stack

**Frontend:**
- React 18+
- TypeScript
- Vite (build tool)
- Tailwind CSS (styling)
- shadcn/ui (components)
- Firebase SDK (real-time updates)

**Backend:**
- Firebase Cloud Functions (Node.js 18)
- Firebase Realtime Database
- SendGrid / Nodemailer (email)

**Hardware:**
- ESP32 Development Board
- DHT22 (Temperature & Humidity)
- DS18B20 (Water Temperature)
- MQ-135 (Gas Sensor)
- pH & Soil Moisture Sensors

## 🎯 Key Features

✅ **Real-time Sensor Processing**
- Automatic temperature, humidity, and soil moisture analysis
- pH level classification
- Gas level danger detection
- Intelligent recommendations

✅ **Automatic Control**
- Smart pump activation (soil moisture < 300)
- Smart fan activation (temperature > 35°C)
- Control history logging

✅ **Email Alerts**
- Multi-level severity system (Low, Medium, High)
- 6 alert types for different conditions
- SendGrid and Gmail SMTP support

✅ **Security**
- Role-based database access control
- Input validation on all data
- Secure environment configuration
- HTTPS enforcement

✅ **Scalability**
- Unlimited device support
- Auto-scaling Cloud Functions
- Modular architecture

## 🚢 Deployment

### Frontend
```bash
npm run build
npm run preview
```

### Backend
```bash
cd functions
firebase deploy
```

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed production setup.

## 🤝 Contributing

Contributions are welcome! Please follow these guidelines:
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

MIT License - see LICENSE file for details

## 🙋 Support

For issues, questions, or suggestions:
1. Check the [documentation](./DOCUMENTATION.md)
2. Review [troubleshooting guides](./DEPLOYMENT.md#troubleshooting)
3. Open an issue on GitHub

---

**Ready to get started?** ➡️ [Read QUICKSTART.md](./QUICKSTART.md)
