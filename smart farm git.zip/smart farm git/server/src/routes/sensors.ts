import express from 'express'
import prisma from '../prismaClient'
import jwt from 'jsonwebtoken'

const router = express.Router()
const JWT_SECRET = process.env.JWT_SECRET || 'change-me'

function authMiddleware(req: any, res: any, next: any) {
  const auth = req.headers.authorization
  if (!auth) return res.status(401).json({ error: 'missing auth' })
  const parts = auth.split(' ')
  if (parts.length !== 2) return res.status(401).json({ error: 'invalid auth' })
  try {
    const payload: any = jwt.verify(parts[1], JWT_SECRET)
    req.userId = payload.userId
    next()
  } catch (e) {
    return res.status(401).json({ error: 'invalid token' })
  }
}

router.post('/data', authMiddleware, async (req: any, res) => {
  const { sensorId, temperature, soilMoisture, ph } = req.body
  const entry = await prisma.sensorData.create({
    data: {
      sensorId,
      temperature: temperature ?? null,
      soilMoisture: soilMoisture ?? null,
      ph: ph ?? null,
      user: req.userId ? { connect: { id: req.userId } } : undefined
    }
  })
  res.json(entry)
})

router.get('/latest/:sensorId', async (req, res) => {
  const sensorId = req.params.sensorId
  const entry = await prisma.sensorData.findFirst({
    where: { sensorId },
    orderBy: { createdAt: 'desc' }
  })
  res.json(entry)
})

export default router
