import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import authRoutes from './routes/auth'
import sensorRoutes from './routes/sensors'
import prisma from './prismaClient'

dotenv.config()

const app = express()
app.use(cors())
app.use(express.json())

app.use('/api/auth', authRoutes)
app.use('/api/sensors', sensorRoutes)

app.get('/api/health', (req, res) => res.json({ ok: true }))

const PORT = Number(process.env.PORT || 4000)

app.listen(PORT, async () => {
  console.log(`Backend listening on http://localhost:${PORT}`)
  try {
    await prisma.$connect()
    console.log('Connected to database (if configured).')
  } catch (e) {
    console.warn('Database connection failed (check DATABASE_URL).')
  }
})
