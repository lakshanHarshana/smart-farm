# Green Monitor Backend

Scaffolded Express + TypeScript backend using Prisma (Postgres), JWT auth, and simple sensor endpoints.

Quick start:

1. Copy `.env.example` to `.env` and set `DATABASE_URL` and `JWT_SECRET`.
2. Install deps:

```bash
cd server
npm install
```

3. Generate Prisma client:

```bash
npx prisma generate
```

4. Run dev server:

```bash
npm run dev
```

Notes: If you don't have Postgres yet, you can still run the server — prisma client generation works without an active DB, but migrations will require a DB.
