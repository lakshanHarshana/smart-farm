# Green Monitor Hub Backend Deployment Guide

## Overview

This document provides step-by-step instructions for deploying the Green Monitor Hub Firebase backend system.

## Prerequisites

- Node.js 18 or higher
- Firebase CLI installed globally
- Firebase project created (https://console.firebase.google.com)
- Email service configured (SendGrid or Gmail SMTP)

## Installation Steps

### 1. Install Firebase CLI

```bash
npm install -g firebase-tools
```

### 2. Authenticate with Firebase

```bash
firebase login
```

This will open a browser window for authentication. Log in with your Google account.

### 3. Initialize Firebase Project

Navigate to the project root directory:

```bash
cd c:\Users\laksh\Desktop\green-monitor-hub-main
```

Initialize Firebase (if not already done):

```bash
firebase init
```

Select the following options:
- ✔ Database (Realtime Database)
- ✔ Functions (Cloud Functions)
- ✔ Emulators

### 4. Configure Environment Variables

1. Copy the environment template:

```bash
copy functions\.env.example functions\.env
```

2. Edit `functions\.env` with your configuration:

```env
FIREBASE_PROJECT_ID=your-actual-project-id
FIREBASE_DATABASE_URL=https://your-project-id.firebaseio.com

# For SendGrid
SENDGRID_API_KEY=your-sendgrid-api-key
SENDGRID_FROM_EMAIL=noreply@greenmonitor.com

# Or for Gmail SMTP
USE_NODEMAILER=false
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-google-app-password

DEFAULT_ALERT_EMAIL=farmer@example.com
```

### 5. Configure .firebaserc

Update `.firebaserc` with your project ID:

```json
{
  "projects": {
    "default": "your-actual-project-id"
  }
}
```

### 6. Install Dependencies

```bash
cd functions
npm install
cd ..
```

### 7. Test Locally

Start the emulator:

```bash
firebase emulators:start
```

This will start:
- Functions emulator on `http://localhost:5001`
- Realtime Database emulator on `http://localhost:9000`

### 8. Load Database Rules

During local testing, import the security rules:

```bash
firebase database:set --data @functions/database.rules.json /
```

## Deployment

### Deploy Cloud Functions Only

```bash
firebase deploy --only functions
```

### Deploy Database Rules Only

```bash
firebase deploy --only database
```

### Deploy Everything

```bash
firebase deploy
```

### View Deployment Logs

```bash
firebase functions:log
```

## Local Testing

### Test with Emulator

While the emulator is running, test the functions by writing data to the database.

Use the Firebase Console UI at `http://localhost:4000` (Emulator Suite).

### Simulate Sensor Data

In the Emulator Database Console, write test data:

Path: `greenMonitorHub/devices/device001/raw`

```json
{
  "temperature": 32,
  "humidity": 65,
  "soilMoisture": 250,
  "pH": 6.5,
  "gasLevel": 450,
  "waterTemp": 22,
  "timestamp": 1704067200000
}
```

This should trigger the cloud function to:
1. Process the data
2. Generate alerts (dry soil + high temperature)
3. Write control commands (pump: true, fan: true)
4. Send email notifications

## Production Configuration

### SendGrid Setup

1. Create SendGrid account: https://sendgrid.com
2. Generate API key in SendGrid Dashboard
3. Add to `functions/.env`:
   ```env
   SENDGRID_API_KEY=SG.xxxxxxxxxxxxxxxxxxxxxxxx
   USE_NODEMAILER=false
   ```

### Gmail SMTP Setup

1. Enable 2-factor authentication on Gmail
2. Generate App Password: https://myaccount.google.com/apppasswords
3. Add to `functions/.env`:
   ```env
   USE_NODEMAILER=true
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USER=your-email@gmail.com
   SMTP_PASS=xxxx xxxx xxxx xxxx
   ```

## Scaling Considerations

### Multiple Devices

The system supports unlimited devices. Configuration per device:

```
/greenMonitorHub/devices/device001/
├── raw/ (sensor data)
├── processed/ (processed data)
├── control/ (control commands)
└── config/ (device configuration)
```

### Custom Thresholds

Edit `functions/utils/config.js` to modify sensor thresholds globally:

```javascript
const THRESHOLDS = {
  soilMoisture: {
    dry: 300,  // Adjust this value
  },
  // ... other thresholds
};
```

### Adding New Sensors

1. Add sensor to ESP32 code
2. Add sensor handling in `processingService.js`
3. Add sensor validation in `database.rules.json`
4. Update email template in `emailService.js`

## Monitoring and Debugging

### View Cloud Function Logs

```bash
firebase functions:log --lines 50
```

### Check Database Rules

```bash
firebase database:get / --export
```

### Test Email Notifications

Use the `resolveAlert` function to test email sending:

1. Trigger an alert through sensor data
2. Check if email was received

### Monitor Database Storage

Use Firebase Console to check:
- Database usage
- Real-time read/write rates
- Storage consumption

## Troubleshooting

### Issue: Cloud Function Times Out

**Solution:**
- Check database connectivity
- Verify email service configuration
- Check function logs for specific errors

### Issue: Emails Not Sending

**Solution:**
1. Verify SendGrid/Nodemailer credentials
2. Check spam folder
3. Review function logs: `firebase functions:log`
4. Test with default test account

### Issue: Sensor Data Not Processing

**Solution:**
1. Verify database rules allow writes to `raw` path
2. Check data format matches validation rules
3. Ensure device ID is alphanumeric

### Issue: Control Commands Not Updating

**Solution:**
1. Verify Cloud Function completed successfully
2. Check database permissions for control path
3. Ensure device can read the control node

## Security Checklist

- [ ] Database rules deployed correctly
- [ ] SendGrid/Nodemailer credentials secured
- [ ] ESP32 authentication configured
- [ ] Frontend user access controlled
- [ ] Error logs don't expose sensitive data
- [ ] Backup strategy in place
- [ ] Monitoring alerts configured

## Backup and Recovery

### Backup Database

```bash
firebase database:get / --export > backup.json
```

### Restore Database

```bash
firebase database:set --import backup.json /
```

## Upgrading

When updating the backend:

1. Test locally first
2. Deploy to staging environment
3. Verify all functions working
4. Deploy to production during low-traffic hours
5. Monitor logs for errors

## Support and Maintenance

### Regular Monitoring Tasks

- [ ] Check function execution times
- [ ] Monitor database growth
- [ ] Review alert patterns
- [ ] Update thresholds based on crop needs
- [ ] Archive old alert data

### Scheduled Maintenance

- Weekly: Review logs and alerts
- Monthly: Backup database
- Quarterly: Review and optimize functions
- Annually: Security audit

## Next Steps

1. **Extend with AI/ML:** Add fertilizer recommendations
2. **Mobile Push Notifications:** Integrate Firebase Cloud Messaging
3. **User Authentication:** Implement Admin/Farmer role-based access
4. **Historical Analytics:** Store processed data for analysis
5. **Multi-farm Management:** Scale for multiple farms

## Additional Resources

- [Firebase Documentation](https://firebase.google.com/docs)
- [Cloud Functions Guide](https://firebase.google.com/docs/functions)
- [Realtime Database Rules](https://firebase.google.com/docs/database/security)
- [SendGrid API Reference](https://docs.sendgrid.com/api-reference)
- [Nodemailer Documentation](https://nodemailer.com/)

---

**Last Updated:** March 2, 2026
**Version:** 1.0.0
