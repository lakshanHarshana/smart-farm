/**
 * Green Monitor Hub Cloud Functions
 * Main entry point for all backend processing
 * Triggers on sensor data updates from ESP32 devices
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const processingService = require("./services/processingService");
const alertService = require("./services/alertService");
const controlService = require("./services/controlService");
const emailService = require("./services/emailService");
const log = require("./utils/logger");

// Initialize Firebase Admin SDK
admin.initializeApp();

/**
 * Main Cloud Function: Trigger on sensor data write
 * Path: /greenMonitorHub/devices/{deviceId}/raw
 */
exports.processSensorData = functions
  .database.ref("greenMonitorHub/devices/{deviceId}/raw")
  .onWrite(async (change, context) => {
    const deviceId = context.params.deviceId;
    const rawData = change.after.val();

    log.info("Sensor data received", {
      deviceId,
      rawData,
      timestamp: new Date().toISOString(),
    });

    try {
      // Validate raw data
      if (!validateRawData(rawData)) {
        log.warn("Invalid sensor data received", { deviceId, rawData });
        return {
          success: false,
          message: "Invalid sensor data",
        };
      }

      // 1. Process sensor data
      log.info("Starting sensor data processing", { deviceId });
      const processedData = processingService.processSensorData(rawData);

      // 2. Write processed data to Firebase
      log.info("Writing processed data to database", { deviceId });
      const db = admin.database();
      await db
        .ref(`greenMonitorHub/devices/${deviceId}/processed`)
        .set(processedData);

      // 3. Determine control states
      log.info("Determining control states", { deviceId });
      const controls = controlService.determineControlStates(rawData);

      // 4. Write control commands to Firebase
      log.info("Writing control commands", { deviceId });
      await controlService.writeControlCommands(deviceId, controls);

      // 5. Log control action for audit trail
      await controlService.logControlAction(deviceId, controls, rawData);

      // 6. Check for alert conditions
      log.info("Checking alert conditions", { deviceId });
      const alerts = processingService.checkAlertConditions(
        rawData,
        processedData
      );

      if (alerts.length > 0) {
        // 7. Store alerts in database
        log.info("Storing alerts", { deviceId, alertCount: alerts.length });
        const alertIds = await alertService.storeMultipleAlerts(
          deviceId,
          alerts,
          rawData
        );

        // 8. Get device email configuration
        const deviceRef = await db
          .ref(`greenMonitorHub/devices/${deviceId}`)
          .once("value");
        const deviceConfig = deviceRef.val();
        const farmEmail =
          deviceConfig?.config?.alertEmail || process.env.DEFAULT_ALERT_EMAIL;

        // 9. Send email notifications
        if (farmEmail) {
          log.info("Sending email notifications", {
            deviceId,
            email: farmEmail,
          });

          try {
            const emailPromises = alerts.map((alert) =>
              emailService.sendAlertEmail({
                toEmail: farmEmail,
                deviceId,
                alertType: alert.type,
                severity: alert.severity,
                message: alert.message,
                sensorValues: {
                  temperature: rawData.temperature,
                  humidity: rawData.humidity,
                  soilMoisture: rawData.soilMoisture,
                  pH: rawData.pH,
                  gasLevel: rawData.gasLevel,
                  waterTemp: rawData.waterTemp,
                },
                recommendation: processedData.recommendation,
              })
            );

            await Promise.allSettled(emailPromises);
          } catch (emailError) {
            log.error("Email sending failed but not blocking processing", {
              error: emailError,
            });
            // Log the error but don't fail the entire function
          }
        }
      }

      log.info("Sensor data processing completed successfully", {
        deviceId,
        alertsGenerated: alerts.length,
      });

      return {
        success: true,
        deviceId,
        processedAt: new Date().toISOString(),
        alertsGenerated: alerts.length,
      };
    } catch (error) {
      log.error("Error processing sensor data", {
        deviceId,
        error: error.message,
        stack: error.stack,
      });

      // Send error notification
      try {
        const db = admin.database();
        const errorRef = db
          .ref(`greenMonitorHub/errors/${deviceId}`)
          .push();

        await errorRef.set({
          message: error.message,
          stack: error.stack,
          timestamp: admin.database.ServerValue.TIMESTAMP,
          rawData,
        });
      } catch (errorLoggingError) {
        log.error("Failed to log error", errorLoggingError);
      }

      throw error;
    }
  });

/**
 * Helper function to validate raw sensor data
 */
function validateRawData(rawData) {
  if (!rawData) return false;

  const requiredFields = [
    "temperature",
    "humidity",
    "soilMoisture",
    "pH",
    "gasLevel",
    "waterTemp",
  ];

  for (const field of requiredFields) {
    if (rawData[field] === undefined || rawData[field] === null) {
      return false;
    }
    if (typeof rawData[field] !== "number") {
      return false;
    }
  }

  // Validate sensor value ranges
  if (rawData.temperature < -50 || rawData.temperature > 60) return false;
  if (rawData.humidity < 0 || rawData.humidity > 100) return false;
  if (rawData.soilMoisture < 0 || rawData.soilMoisture > 1024) return false;
  if (rawData.pH < 0 || rawData.pH > 14) return false;
  if (rawData.gasLevel < 0) return false;
  if (rawData.waterTemp < -10 || rawData.waterTemp > 50) return false;

  return true;
}

/**
 * Helper function for manually checking alerts for a device
 * Can be called via Firebase Console
 */
exports.getDeviceAlerts = functions.https.onCall(async (data, context) => {
  try {
    const { deviceId } = data;

    if (!deviceId) {
      throw new Error("deviceId is required");
    }

    const alerts = await alertService.getUnresolvedAlerts(deviceId);
    const stats = await alertService.getAlertStatistics(deviceId);

    return {
      success: true,
      alerts,
      statistics: stats,
    };
  } catch (error) {
    log.error("Error in getDeviceAlerts", error);
    throw error;
  }
});

/**
 * Helper function to manually resolve an alert
 */
exports.resolveAlert = functions.https.onCall(async (data, context) => {
  try {
    const { alertId } = data;

    if (!alertId) {
      throw new Error("alertId is required");
    }

    await alertService.resolveAlert(alertId);

    return {
      success: true,
      message: "Alert resolved successfully",
    };
  } catch (error) {
    log.error("Error in resolveAlert", error);
    throw error;
  }
});

/**
 * Helper function to get device alert statistics
 */
exports.getAlertStatistics = functions.https.onCall(async (data, context) => {
  try {
    const { deviceId } = data;

    if (!deviceId) {
      throw new Error("deviceId is required");
    }

    const stats = await alertService.getAlertStatistics(deviceId);

    return {
      success: true,
      statistics: stats,
    };
  } catch (error) {
    log.error("Error in getAlertStatistics", error);
    throw error;
  }
});

/**
 * Helper function to get device control history
 */
exports.getControlHistory = functions.https.onCall(async (data, context) => {
  try {
    const { deviceId, limit = 20 } = data;

    if (!deviceId) {
      throw new Error("deviceId is required");
    }

    const history = await controlService.getControlHistory(deviceId, limit);

    return {
      success: true,
      history,
    };
  } catch (error) {
    log.error("Error in getControlHistory", error);
    throw error;
  }
});

/**
 * HTTP endpoint for ESP32 health check
 */
exports.healthCheck = functions.https.onRequest((req, res) => {
  res.status(200).json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    service: "Green Monitor Hub Cloud Functions",
  });
});

log.info("Cloud Functions initialized successfully");
