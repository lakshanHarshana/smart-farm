/**
 * Configuration and threshold values for sensor processing
 * Centralized configuration for easy updates and scalability
 */

const THRESHOLDS = {
  soilMoisture: {
    dry: 300,
    normal: 300,
  },
  pH: {
    acidic: 5.5,
    alkaline: 7.5,
  },
  gas: {
    danger: 500,
  },
  temperature: {
    high: 35,
  },
};

const ALERT_SEVERITY = {
  LOW: "Low",
  MEDIUM: "Medium",
  HIGH: "High",
};

const ALERT_TYPES = {
  DRY_SOIL: "dry_soil",
  DANGEROUS_GAS: "dangerous_gas",
  EXTREME_TEMPERATURE: "extreme_temperature",
  ACIDIC_SOIL: "acidic_soil",
  ALKALINE_SOIL: "alkaline_soil",
  HIGH_HUMIDITY: "high_humidity",
};

const EMAIL_CONFIG = {
  fromEmail: process.env.SENDGRID_FROM_EMAIL || "noreply@greenmonitor.com",
  fromName: "Green Monitor Hub",
  sendgridApiKey: process.env.SENDGRID_API_KEY,
  useNodemailer: process.env.USE_NODEMAILER === "true",
  nodemailer: {
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: parseInt(process.env.SMTP_PORT || "587"),
    secure: process.env.SMTP_SECURE === "true",
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  },
};

const FIREBASE_CONFIG = {
  databaseURL: process.env.FIREBASE_DATABASE_URL,
  projectId: process.env.FIREBASE_PROJECT_ID,
};

module.exports = {
  THRESHOLDS,
  ALERT_SEVERITY,
  ALERT_TYPES,
  EMAIL_CONFIG,
  FIREBASE_CONFIG,
};
