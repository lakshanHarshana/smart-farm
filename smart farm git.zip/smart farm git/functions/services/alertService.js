/**
 * Alert Service
 * Handles alert logging and email notifications
 */

const admin = require("firebase-admin");
const log = require("../utils/logger");

/**
 * Store alert in Realtime Database
 * @param {string} deviceId - Device ID
 * @param {Object} alert - Alert object
 * @param {string} rawData - Raw sensor data
 * @returns {Promise<string>} Alert ID
 */
async function storeAlert(deviceId, alert, rawData) {
  try {
    const db = admin.database();
    const alertRef = db.ref("greenMonitorHub/alerts").push();
    
    const alertData = {
      deviceId,
      type: alert.type,
      severity: alert.severity,
      message: alert.message,
      sensorValue: alert.value,
      rawData,
      timestamp: admin.database.ServerValue.TIMESTAMP,
      isResolved: false,
      resolvedAt: null,
    };

    await alertRef.set(alertData);
    
    log.info("Alert stored in database", {
      alertId: alertRef.key,
      deviceId,
      alertType: alert.type,
    });

    return alertRef.key;
  } catch (error) {
    log.error("Error storing alert", error);
    throw error;
  }
}

/**
 * Store multiple alerts
 * @param {string} deviceId - Device ID
 * @param {Array} alerts - Array of alert objects
 * @param {string} rawData - Raw sensor data
 * @returns {Promise<Array>} Array of alert IDs
 */
async function storeMultipleAlerts(deviceId, alerts, rawData) {
  try {
    const alertIds = [];
    
    for (const alert of alerts) {
      const alertId = await storeAlert(deviceId, alert, rawData);
      alertIds.push(alertId);
    }

    return alertIds;
  } catch (error) {
    log.error("Error storing multiple alerts", error);
    throw error;
  }
}

/**
 * Get recent unresolved alerts for a device
 * @param {string} deviceId - Device ID
 * @param {number} limit - Number of alerts to retrieve
 * @returns {Promise<Array>} Array of alerts
 */
async function getUnresolvedAlerts(deviceId, limit = 10) {
  try {
    const db = admin.database();
    const snapshot = await db
      .ref("greenMonitorHub/alerts")
      .orderByChild("deviceId")
      .equalTo(deviceId)
      .limitToLast(limit)
      .once("value");

    const alerts = [];
    snapshot.forEach((child) => {
      const alert = child.val();
      if (!alert.isResolved) {
        alerts.push({
          id: child.key,
          ...alert,
        });
      }
    });

    return alerts;
  } catch (error) {
    log.error("Error getting unresolved alerts", error);
    throw error;
  }
}

/**
 * Resolve an alert
 * @param {string} alertId - Alert ID
 * @returns {Promise<void>}
 */
async function resolveAlert(alertId) {
  try {
    const db = admin.database();
    await db.ref(`greenMonitorHub/alerts/${alertId}`).update({
      isResolved: true,
      resolvedAt: admin.database.ServerValue.TIMESTAMP,
    });

    log.info("Alert resolved", { alertId });
  } catch (error) {
    log.error("Error resolving alert", error);
    throw error;
  }
}

/**
 * Get alert statistics for a device
 * @param {string} deviceId - Device ID
 * @returns {Promise<Object>} Alert statistics
 */
async function getAlertStatistics(deviceId) {
  try {
    const db = admin.database();
    const snapshot = await db
      .ref("greenMonitorHub/alerts")
      .orderByChild("deviceId")
      .equalTo(deviceId)
      .once("value");

    const stats = {
      total: 0,
      resolved: 0,
      unresolved: 0,
      bySeverity: {
        Low: 0,
        Medium: 0,
        High: 0,
      },
    };

    snapshot.forEach((child) => {
      const alert = child.val();
      stats.total++;
      if (alert.isResolved) {
        stats.resolved++;
      } else {
        stats.unresolved++;
      }
      if (stats.bySeverity[alert.severity]) {
        stats.bySeverity[alert.severity]++;
      }
    });

    return stats;
  } catch (error) {
    log.error("Error getting alert statistics", error);
    throw error;
  }
}

module.exports = {
  storeAlert,
  storeMultipleAlerts,
  getUnresolvedAlerts,
  resolveAlert,
  getAlertStatistics,
};
