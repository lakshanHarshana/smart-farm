/**
 * Control Service
 * Handles automatic control of pump, fan, and other actuators
 */

const admin = require("firebase-admin");
const { THRESHOLDS } = require("../utils/config");
const log = require("../utils/logger");

/**
 * Determine control states based on sensor data
 * @param {Object} rawData - Raw sensor data
 * @returns {Object} Control states
 */
function determineControlStates(rawData) {
  const controls = {
    pump: determinePumpState(rawData.soilMoisture),
    fan: determineFanState(rawData.temperature),
    updatedAt: new Date().toISOString(),
  };

  log.info("Control states determined", controls);
  return controls;
}

/**
 * Determine if pump should be active
 * Pump activates when soil moisture is below threshold
 */
function determinePumpState(soilMoisture) {
  return soilMoisture < THRESHOLDS.soilMoisture.dry;
}

/**
 * Determine if fan should be active
 * Fan activates when temperature exceeds threshold
 */
function determineFanState(temperature) {
  return temperature > THRESHOLDS.temperature.high;
}

/**
 * Write control commands to Firebase
 * @param {string} deviceId - Device ID
 * @param {Object} controls - Control states
 * @returns {Promise<void>}
 */
async function writeControlCommands(deviceId, controls) {
  try {
    const db = admin.database();
    const controlRef = db.ref(`greenMonitorHub/devices/${deviceId}/control`);

    const controlData = {
      pump: controls.pump,
      fan: controls.fan,
      updatedAt: admin.database.ServerValue.TIMESTAMP,
    };

    await controlRef.set(controlData);

    log.info("Control commands written to database", {
      deviceId,
      controls: controlData,
    });
  } catch (error) {
    log.error("Error writing control commands", error);
    throw error;
  }
}

/**
 * Get current control state for a device
 * @param {string} deviceId - Device ID
 * @returns {Promise<Object>} Current control state
 */
async function getControlState(deviceId) {
  try {
    const db = admin.database();
    const snapshot = await db
      .ref(`greenMonitorHub/devices/${deviceId}/control`)
      .once("value");

    return snapshot.val();
  } catch (error) {
    log.error("Error getting control state", error);
    throw error;
  }
}

/**
 * Get control history for a device
 * @param {string} deviceId - Device ID
 * @param {number} limit - Number of recent controls to retrieve
 * @returns {Promise<Array>} Control history
 */
async function getControlHistory(deviceId, limit = 20) {
  try {
    const db = admin.database();
    const snapshot = await db
      .ref(`greenMonitorHub/devices/${deviceId}/controlHistory`)
      .limitToLast(limit)
      .once("value");

    const history = [];
    snapshot.forEach((child) => {
      history.push({
        id: child.key,
        ...child.val(),
      });
    });

    return history.reverse();
  } catch (error) {
    log.error("Error getting control history", error);
    throw error;
  }
}

/**
 * Log control action for audit trail
 * @param {string} deviceId - Device ID
 * @param {Object} controls - Control states
 * @param {Object} rawData - Raw sensor data that triggered the control
 * @returns {Promise<string>} Control history entry ID
 */
async function logControlAction(deviceId, controls, rawData) {
  try {
    const db = admin.database();
    const historyRef = db
      .ref(`greenMonitorHub/devices/${deviceId}/controlHistory`)
      .push();

    const logEntry = {
      pump: controls.pump,
      fan: controls.fan,
      triggeredBy: {
        soilMoisture: rawData.soilMoisture,
        temperature: rawData.temperature,
      },
      timestamp: admin.database.ServerValue.TIMESTAMP,
    };

    await historyRef.set(logEntry);

    log.info("Control action logged", {
      deviceId,
      entryId: historyRef.key,
    });

    return historyRef.key;
  } catch (error) {
    log.error("Error logging control action", error);
    throw error;
  }
}

module.exports = {
  determineControlStates,
  determinePumpState,
  determineFanState,
  writeControlCommands,
  getControlState,
  getControlHistory,
  logControlAction,
};
