/**
 * Processing Service
 * Handles sensor data analysis and status determination
 */

const { THRESHOLDS, ALERT_TYPES } = require("../utils/config");
const log = require("../utils/logger");

/**
 * Process sensor raw data and determine statuses
 * @param {Object} rawData - Raw sensor data from ESP32
 * @returns {Object} Processed data with status information
 */
function processSensorData(rawData) {
  try {
    const processed = {
      soilStatus: determineSoilMoistureStatus(rawData.soilMoisture),
      phStatus: determinePHStatus(rawData.pH),
      gasStatus: determineGasStatus(rawData.gasLevel),
      temperatureStatus: determineTemperatureStatus(rawData.temperature),
      humidityStatus: determineHumidityStatus(rawData.humidity),
      waterTempStatus: determineWaterTempStatus(rawData.waterTemp),
      recommendation: generateRecommendation(rawData),
      processedAt: new Date().toISOString(),
    };

    log.info("Sensor data processed successfully", {
      rawData,
      processed,
    });

    return processed;
  } catch (error) {
    log.error("Error processing sensor data", error);
    throw error;
  }
}

/**
 * Determine soil moisture status
 */
function determineSoilMoistureStatus(soilMoisture) {
  if (soilMoisture < THRESHOLDS.soilMoisture.dry) {
    return "Dry";
  }
  return "Normal";
}

/**
 * Determine pH status
 */
function determinePHStatus(pH) {
  if (pH < THRESHOLDS.pH.acidic) {
    return "Acidic";
  }
  if (pH > THRESHOLDS.pH.alkaline) {
    return "Alkaline";
  }
  return "Normal";
}

/**
 * Determine gas level status
 */
function determineGasStatus(gasLevel) {
  if (gasLevel > THRESHOLDS.gas.danger) {
    return "Danger";
  }
  return "Safe";
}

/**
 * Determine temperature status
 */
function determineTemperatureStatus(temperature) {
  if (temperature > THRESHOLDS.temperature.high) {
    return "High";
  }
  return "Normal";
}

/**
 * Determine humidity status
 */
function determineHumidityStatus(humidity) {
  if (humidity > 80) {
    return "High";
  }
  if (humidity < 30) {
    return "Low";
  }
  return "Normal";
}

/**
 * Determine water temperature status
 */
function determineWaterTempStatus(waterTemp) {
  if (waterTemp < 10) {
    return "Cold";
  }
  if (waterTemp > 30) {
    return "Warm";
  }
  return "Optimal";
}

/**
 * Generate recommendation based on sensor readings
 */
function generateRecommendation(rawData) {
  const recommendations = [];

  if (rawData.soilMoisture < THRESHOLDS.soilMoisture.dry) {
    recommendations.push("Soil is dry - activate irrigation pump");
  }

  if (rawData.temperature > THRESHOLDS.temperature.high) {
    recommendations.push("Temperature is high - activate cooling fan");
  }

  if (rawData.pH < THRESHOLDS.pH.acidic) {
    recommendations.push("Soil is too acidic - add lime to neutralize pH");
  }

  if (rawData.pH > THRESHOLDS.pH.alkaline) {
    recommendations.push("Soil is too alkaline - add sulfur to lower pH");
  }

  if (rawData.gasLevel > THRESHOLDS.gas.danger) {
    recommendations.push("Dangerous gas level detected - check sensors and improve ventilation");
  }

  if (recommendations.length === 0) {
    recommendations.push("All conditions normal - continue monitoring");
  }

  return recommendations.join(" | ");
}

/**
 * Check if alert should be triggered
 * @param {Object} rawData - Raw sensor data
 * @param {Object} processed - Processed sensor data
 * @returns {Array} Array of alert objects that need to be triggered
 */
function checkAlertConditions(rawData, processed) {
  const alerts = [];

  // Dry soil alert
  if (processed.soilStatus === "Dry") {
    alerts.push({
      type: ALERT_TYPES.DRY_SOIL,
      severity: "Medium",
      message: `Soil moisture is low (${rawData.soilMoisture}). Pump will be activated.`,
      value: rawData.soilMoisture,
    });
  }

  // Dangerous gas alert
  if (processed.gasStatus === "Danger") {
    alerts.push({
      type: ALERT_TYPES.DANGEROUS_GAS,
      severity: "High",
      message: `Dangerous gas level detected (${rawData.gasLevel}ppm). Immediate action required.`,
      value: rawData.gasLevel,
    });
  }

  // Extreme temperature alert
  if (processed.temperatureStatus === "High") {
    alerts.push({
      type: ALERT_TYPES.EXTREME_TEMPERATURE,
      severity: "Medium",
      message: `Temperature is high (${rawData.temperature}°C). Fan will be activated.`,
      value: rawData.temperature,
    });
  }

  // Acidic soil alert
  if (processed.phStatus === "Acidic") {
    alerts.push({
      type: ALERT_TYPES.ACIDIC_SOIL,
      severity: "Low",
      message: `Soil is acidic (pH: ${rawData.pH}). Consider adjusting soil pH.`,
      value: rawData.pH,
    });
  }

  // Alkaline soil alert
  if (processed.phStatus === "Alkaline") {
    alerts.push({
      type: ALERT_TYPES.ALKALINE_SOIL,
      severity: "Low",
      message: `Soil is alkaline (pH: ${rawData.pH}). Consider adjusting soil pH.`,
      value: rawData.pH,
    });
  }

  // High humidity alert
  if (processed.humidityStatus === "High") {
    alerts.push({
      type: ALERT_TYPES.HIGH_HUMIDITY,
      severity: "Low",
      message: `Humidity is high (${rawData.humidity}%). Improve ventilation.`,
      value: rawData.humidity,
    });
  }

  log.info("Alert conditions checked", { alertCount: alerts.length, alerts });

  return alerts;
}

module.exports = {
  processSensorData,
  checkAlertConditions,
  determineSoilMoistureStatus,
  determinePHStatus,
  determineGasStatus,
  determineTemperatureStatus,
};
