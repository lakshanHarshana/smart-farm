/**
 * Email Notification Service
 * Supports both SendGrid and Nodemailer
 */

const log = require("../utils/logger");
const { EMAIL_CONFIG } = require("../utils/config");
let sgMail;
let transporter;

// Initialize SendGrid if API key is available
if (EMAIL_CONFIG.sendgridApiKey && !EMAIL_CONFIG.useNodemailer) {
  sgMail = require("@sendgrid/mail");
  sgMail.setApiKey(EMAIL_CONFIG.sendgridApiKey);
  log.info("SendGrid initialized");
}

// Initialize Nodemailer if configured
if (EMAIL_CONFIG.useNodemailer) {
  const nodemailer = require("nodemailer");
  transporter = nodemailer.createTransport(EMAIL_CONFIG.nodemailer);
  log.info("Nodemailer initialized");
}

/**
 * Send alert email
 * @param {Object} options - Email options
 * @returns {Promise<void>}
 */
async function sendAlertEmail(options) {
  const {
    toEmail,
    deviceId,
    alertType,
    severity,
    message,
    sensorValues,
    recommendation,
  } = options;

  try {
    const subject = `Smart Farm Alert – Green Monitor Hub [${severity}]`;
    const html = generateAlertEmailHTML({
      deviceId,
      alertType,
      severity,
      message,
      sensorValues,
      recommendation,
    });

    if (sgMail && !EMAIL_CONFIG.useNodemailer) {
      await sendViaSendGrid(toEmail, subject, html);
    } else if (transporter) {
      await sendViaNodemailer(toEmail, subject, html);
    } else {
      log.warn("No email service configured", { options });
    }
  } catch (error) {
    log.error("Error sending alert email", error);
    throw error;
  }
}

/**
 * Send email via SendGrid
 */
async function sendViaSendGrid(toEmail, subject, html) {
  try {
    const msg = {
      to: toEmail,
      from: EMAIL_CONFIG.fromEmail,
      replyTo: EMAIL_CONFIG.fromEmail,
      subject,
      html,
    };

    await sgMail.send(msg);
    log.info("Email sent via SendGrid", { toEmail });
  } catch (error) {
    log.error("SendGrid error", error);
    throw error;
  }
}

/**
 * Send email via Nodemailer
 */
async function sendViaNodemailer(toEmail, subject, html) {
  try {
    const mailOptions = {
      from: EMAIL_CONFIG.fromEmail,
      to: toEmail,
      subject,
      html,
    };

    await transporter.sendMail(mailOptions);
    log.info("Email sent via Nodemailer", { toEmail });
  } catch (error) {
    log.error("Nodemailer error", error);
    throw error;
  }
}

/**
 * Generate alert email HTML
 */
function generateAlertEmailHTML(data) {
  const { deviceId, alertType, severity, message, sensorValues, recommendation } = data;
  const severityColors = {
    Low: "#4CAF50",
    Medium: "#FF9800",
    High: "#F44336",
  };

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #2C3E50; color: white; padding: 20px; border-radius: 5px; }
          .alert-badge { 
            display: inline-block; 
            padding: 8px 16px; 
            border-radius: 5px; 
            color: white; 
            font-weight: bold;
            background-color: ${severityColors[severity] || '#999'};
            margin: 10px 0;
          }
          .content { border: 1px solid #ddd; padding: 20px; margin: 20px 0; }
          .sensor-value { padding: 10px; background-color: #f5f5f5; margin: 5px 0; border-left: 4px solid #2C3E50; }
          .recommendation { 
            background-color: #E8F5E9; 
            padding: 15px; 
            border-left: 4px solid #4CAF50;
            margin: 15px 0;
          }
          .footer { text-align: center; color: #999; font-size: 12px; margin-top: 30px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🌱 Green Monitor Hub Alert</h1>
            <p>Smart Farm Monitoring System</p>
          </div>

          <div class="content">
            <p><strong>Device ID:</strong> ${deviceId}</p>
            <p><strong>Alert Type:</strong> ${alertType}</p>
            <div class="alert-badge">${severity} Severity</div>
            <p><strong>Message:</strong></p>
            <p>${message}</p>

            <h3>Sensor Values</h3>
            ${Object.entries(sensorValues || {})
              .map(
                ([key, value]) => `
              <div class="sensor-value">
                <strong>${formatSensorName(key)}:</strong> ${formatSensorValue(key, value)}
              </div>
            `
              )
              .join("")}

            <div class="recommendation">
              <h4>Recommended Action:</h4>
              <p>${recommendation}</p>
            </div>

            <p style="color: #999; margin-top: 20px;">
              <em>This is an automated alert from your Green Monitor Hub system. 
              Please review and take appropriate action if needed.</em>
            </p>
          </div>

          <div class="footer">
            <p>Green Monitor Hub © 2024 | Smart Farm Monitoring System</p>
          </div>
        </div>
      </body>
    </html>
  `;
}

/**
 * Format sensor name for display
 */
function formatSensorName(key) {
  return key
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (str) => str.toUpperCase())
    .trim();
}

/**
 * Format sensor value with appropriate units
 */
function formatSensorValue(key, value) {
  const unitMap = {
    temperature: "°C",
    humidity: "%",
    pH: "",
    soilMoisture: "",
    gasLevel: "ppm",
    waterTemp: "°C",
  };

  const unit = unitMap[key] || "";
  return `${value}${unit}`;
}

/**
 * Send batch emails
 * @param {Array} emails - Array of email options
 * @returns {Promise<void>}
 */
async function sendBatchEmails(emails) {
  try {
    const results = await Promise.allSettled(
      emails.map((emailOption) => sendAlertEmail(emailOption))
    );

    const successful = results.filter((r) => r.status === "fulfilled").length;
    const failed = results.filter((r) => r.status === "rejected").length;

    log.info("Batch emails sent", { successful, failed, total: emails.length });

    if (failed > 0) {
      log.warn(`${failed} emails failed to send`, {
        failures: results
          .map((r, i) => ({ index: i, reason: r.reason?.message }))
          .filter((r) => r.reason),
      });
    }
  } catch (error) {
    log.error("Error sending batch emails", error);
    throw error;
  }
}

module.exports = {
  sendAlertEmail,
  sendBatchEmails,
};
