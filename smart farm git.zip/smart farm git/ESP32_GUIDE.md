# ESP32 Integration Guide

Guide for configuring ESP32 devices to send sensor data to Green Monitor Hub backend.

## Hardware Setup

### Required Components

- ESP32 Development Board
- DHT22 Temperature/Humidity Sensor
- Waterproof Temperature Sensor (DS18B20)
- MQ-135 or similar Gas Sensor
- Analog pH Sensor Kit
- Analog Humidity Sensor
- Capacitive Soil Moisture Sensor
- Relay modules for pump and fan control
- 5V Power Supply

### Pin Configuration

```
Sensor/Actuator          GPIO Pin
─────────────────────────────────
DHT22                    GPIO 26
DS18B20 (Water Temp)     GPIO 14
MQ-135 (Gas)             GPIO 36 (A0)
pH Sensor                GPIO 39 (A2)
Humidity Sensor          GPIO 34 (A6)
Soil Moisture            GPIO 35 (A7)
Pump Relay               GPIO 19
Fan Relay                GPIO 18
```

## Firmware Development

### Arduino IDE Setup

1. Install ESP32 board support
2. Select board: ESP32 Dev Module
3. Set baud rate: 115200

### Required Libraries

```cpp
#include <WiFi.h>
#include <Firebase.h>
#include <DHT.h>
#include <OneWire.h>
#include <DallasTemperature.h>
```

### Basic Firmware Template

```cpp
#include <WiFi.h>
#include <Firebase.h>
#include <FirebaseArduino.h>
#include <DHT.h>

// Firebase Configuration
#define FIREBASE_HOST "your-project.firebaseio.com"
#define FIREBASE_AUTH "your-database-secret"

// WiFi Configuration
#define WIFI_SSID "your-ssid"
#define WIFI_PASSWORD "your-password"

// Sensor Configuration
#define DHT_PIN 26
#define DHTTYPE DHT22
#define ONE_WIRE_BUS 14
#define GAS_SENSOR_PIN 36
#define PH_SENSOR_PIN 39
#define HUMIDITY_SENSOR_PIN 34
#define SOIL_MOISTURE_PIN 35

// Actuator Configuration
#define PUMP_RELAY_PIN 19
#define FAN_RELAY_PIN 18

// Device Configuration
#define DEVICE_ID "device001"
#define UPLOAD_INTERVAL 300000  // 5 minutes in milliseconds

// Initialize sensors
DHT dht(DHT_PIN, DHTTYPE);
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

// Global variables
unsigned long lastUploadTime = 0;
bool pumpActive = false;
bool fanActive = false;

void setup() {
  Serial.begin(115200);
  delay(2000);

  // Initialize pins
  pinMode(PUMP_RELAY_PIN, OUTPUT);
  pinMode(FAN_RELAY_PIN, OUTPUT);
  digitalWrite(PUMP_RELAY_PIN, LOW);
  digitalWrite(FAN_RELAY_PIN, LOW);

  // Initialize sensors
  dht.begin();
  sensors.begin();

  // Connect to WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }
  Serial.println("\nWiFi connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());

  // Initialize Firebase
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  Firebase.reconnectWiFi(true);
}

void loop() {
  unsigned long currentTime = millis();

  // Check if it's time to upload data
  if (currentTime - lastUploadTime >= UPLOAD_INTERVAL) {
    readAndUploadSensorData();
    checkAndApplyControls();
    lastUploadTime = currentTime;
  }

  delay(1000);
}

void readAndUploadSensorData() {
  Serial.println("Reading sensor data...");

  // Read temperature and humidity from DHT22
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("DHT22 read failed");
    return;
  }

  // Read water temperature from DS18B20
  sensors.requestTemperatures();
  float waterTemp = sensors.getTempCByIndex(0);

  // Read gas level
  int gasRaw = analogRead(GAS_SENSOR_PIN);
  float gasLevel = convertGasRawToPPM(gasRaw);

  // Read pH
  int phRaw = analogRead(PH_SENSOR_PIN);
  float pH = convertPhRawToValue(phRaw);

  // Read humidity from analog sensor
  int humidityRaw = analogRead(HUMIDITY_SENSOR_PIN);
  float analogHumidity = convertHumidityRawToPercent(humidityRaw);

  // Read soil moisture
  int soilMoistureRaw = analogRead(SOIL_MOISTURE_PIN);
  float soilMoisture = soilMoistureRaw;

  // Log sensor readings
  Serial.println("Sensor Readings:");
  Serial.print("Temperature: ");
  Serial.println(temperature);
  Serial.print("Humidity: ");
  Serial.println(humidity);
  Serial.print("Water Temp: ");
  Serial.println(waterTemp);
  Serial.print("Gas Level: ");
  Serial.println(gasLevel);
  Serial.print("pH: ");
  Serial.println(pH);
  Serial.print("Soil Moisture: ");
  Serial.println(soilMoisture);

  // Create JSON payload
  String path = "/greenMonitorHub/devices/" + String(DEVICE_ID) + "/raw";

  // Write to Firebase
  Firebase.setFloat(path + "/temperature", temperature);
  Firebase.setFloat(path + "/humidity", humidity);
  Firebase.setFloat(path + "/waterTemp", waterTemp);
  Firebase.setFloat(path + "/gasLevel", gasLevel);
  Firebase.setFloat(path + "/pH", pH);
  Firebase.setFloat(path + "/soilMoisture", soilMoisture);
  Firebase.setLong(path + "/timestamp", millis());

  if (Firebase.failed()) {
    Serial.print("Firebase write failed: ");
    Serial.println(Firebase.error());
  } else {
    Serial.println("Data uploaded successfully!");
  }
}

void checkAndApplyControls() {
  Serial.println("Checking for control commands...");

  String controlPath = "/greenMonitorHub/devices/" + String(DEVICE_ID) + "/control";

  // Read control commands from Firebase
  bool pumpCommand = Firebase.getBool(controlPath + "/pump", false);
  bool fanCommand = Firebase.getBool(controlPath + "/fan", false);

  if (Firebase.failed()) {
    Serial.print("Firebase read failed: ");
    Serial.println(Firebase.error());
    return;
  }

  // Apply pump control
  if (pumpCommand != pumpActive) {
    digitalWrite(PUMP_RELAY_PIN, pumpCommand ? HIGH : LOW);
    pumpActive = pumpCommand;
    Serial.print("Pump: ");
    Serial.println(pumpActive ? "ON" : "OFF");
  }

  // Apply fan control
  if (fanCommand != fanActive) {
    digitalWrite(FAN_RELAY_PIN, fanCommand ? HIGH : LOW);
    fanActive = fanCommand;
    Serial.print("Fan: ");
    Serial.println(fanActive ? "ON" : "OFF");
  }
}

// Sensor conversion functions (calibrate based on your sensors)

float convertGasRawToPPM(int raw) {
  // Calibrate based on MQ-135 datasheet
  // This is an approximate conversion
  return raw * 0.5;  // Adjust multiplier based on your sensor
}

float convertPhRawToValue(int raw) {
  // Analog pH sensors typically output 0-1023 for pH 0-14
  float ph = (raw / 1023.0) * 14.0;
  return ph;
}

float convertHumidityRawToPercent(int raw) {
  // Analog humidity sensor - adjust based on your sensor's output
  float humidity = (raw / 4095.0) * 100.0;
  return humidity;
}
```

## Firebase Configuration

### Create Service Account

1. Go to Firebase Console
2. Project Settings → Service Accounts
3. Generate new private key (JSON)
4. Store securely

### Configure Database Access

1. Go to Database → Rules
2. Set ESP32 authentication:

```json
{
  "rules": {
    "greenMonitorHub": {
      "devices": {
        "$deviceId": {
          "raw": {
            ".write": "auth.uid == 'esp32-device'"
          },
          "control": {
            ".read": "auth.uid == 'esp32-device'"
          }
        }
      }
    }
  }
}
```

## Data Format Requirements

### Sensor Data Format

The ESP32 must send data in this exact format to `/greenMonitorHub/devices/{deviceId}/raw`:

```json
{
  "temperature": 28.5,        // °C (float)
  "humidity": 65.0,           // % (float)
  "soilMoisture": 450.0,      // 0-1023 (float)
  "pH": 6.8,                  // 0-14 (float)
  "gasLevel": 400.0,          // ppm (float)
  "waterTemp": 22.5,          // °C (float)
  "timestamp": 1704067200000  // Unix timestamp (long)
}
```

### Validation Rules

- Temperature: -50 to 60°C
- Humidity: 0-100%
- Soil Moisture: 0-1023
- pH: 0-14
- Gas Level: 0+
- Water Temp: -10 to 50°C

## Control Command Format

The ESP32 should read from `/greenMonitorHub/devices/{deviceId}/control`:

```json
{
  "pump": false,           // Boolean
  "fan": true,             // Boolean
  "updatedAt": "2024-01-01T12:00:00Z"
}
```

## Testing

### Serial Output Expected

```
WiFi connected!
IP address: 192.168.1.100
Reading sensor data...
Sensor Readings:
Temperature: 28.50
Humidity: 65.00
Water Temp: 22.50
Gas Level: 400.00
pH: 6.80
Soil Moisture: 450.00
Data uploaded successfully!
Checking for control commands...
Pump: OFF
Fan: ON
```

### Troubleshooting

**WiFi Connection Issues:**
- Verify SSID and password
- Check ESP32 WiFi antenna
- Check signal strength

**Firebase Connection Issues:**
- Verify Firebase credentials
- Check database rules
- Ensure billing enabled

**Sensor Reading Issues:**
- Verify pin connections
- Check sensor power supply
- Calibrate analog sensors
- Review sensor datasheets

## Sensor Calibration

### Soil Moisture Calibration

```cpp
void calibrateSoilMoisture() {
  // Dry: record value with sensor in dry air
  // Wet: record value with sensor in water
  // Use these values to map actual moisture percentage
}
```

### pH Sensor Calibration

```cpp
void calibratePH() {
  // Use calibration solutions (pH 4.0, 7.0, 10.0)
  // Record raw values for each
  // Create linear mapping
}
```

### Gas Sensor Warm-up

Gas sensors need warm-up time:

```cpp
void setup() {
  // ... other initialization
  
  Serial.println("Warming up gas sensor...");
  for (int i = 0; i < 120; i++) {
    analogRead(GAS_SENSOR_PIN);  // Dummy reads
    delay(1000);
  }
  Serial.println("Gas sensor ready!");
}
```

## Power Management

### Deep Sleep Configuration

For battery-powered devices:

```cpp
void sleepMode(int seconds) {
  Serial.println("Entering deep sleep...");
  esp_sleep_enable_timer_wakeup(seconds * 1000000);
  esp_deep_sleep_start();
}
```

### Low Power Upload

```cpp
void setup() {
  // ... initialization
  analogSetAttenuation(ADC_2_5db);  // Lower power ADC
  WiFi.setSleep(true);               // WiFi power saving
}
```

## Over-the-Air Updates

Enable OTA updates:

```cpp
#include <ArduinoOTA.h>

void setupOTA() {
  ArduinoOTA.setHostname("GreenMonitor");
  ArduinoOTA.onStart([]() {
    Serial.println("OTA Update Start");
  });
  ArduinoOTA.onEnd([]() {
    Serial.println("\nOTA Update End");
  });
  ArduinoOTA.begin();
}

void loop() {
  ArduinoOTA.handle();
  // ... rest of loop
}
```

## Production Checklist

- [ ] All sensors calibrated
- [ ] WiFi credentials secure
- [ ] Firebase credentials secured
- [ ] Upload interval set appropriately
- [ ] Error handling implemented
- [ ] Serial logging for debugging
- [ ] OTA updates enabled
- [ ] Power management optimized
- [ ] Tested in actual field conditions
- [ ] Backup strategy for local data

## Next Steps

1. Flash firmware to ESP32
2. Monitor serial output for errors
3. Verify data appears in Firebase Console
4. Test relay activation
5. Verify alerts in email
6. Deploy to field

## Resources

- [ESP32 Documentation](https://docs.espressif.com/projects/esp-idf/en/latest/)
- [Firebase Arduino Library](https://github.com/FirebaseExtended/firebase-arduino)
- [DHT22 Datasheet](https://www.mouser.com/datasheet/2/758/DHT22.pdf)
- [Sensor Integration Guide](../README.md)

---

**Last Updated:** March 2, 2026
**Version:** 1.0.0
