# Frontend Integration Guide

Guide for connecting the React frontend to the Green Monitor Hub Firebase backend.

## Overview

The React frontend reads processed sensor data and alert information from Firebase in real-time, displaying them on the dashboard while remaining agnostic to backend processing details.

## Frontend Architecture

```
React Components
    ↓
Firebase Realtime Database Listeners
    ↓
Real-time Data Updates
    ↓
Dashboard Visualization
```

## Setup

### Install Firebase SDK

```bash
npm install firebase
```

### Firebase Configuration

Create `src/config/firebase.ts`:

```typescript
import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
export const auth = getAuth(app);
```

### Environment Variables

Create `.env`:

```env
VITE_FIREBASE_API_KEY=your-api-key
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your-sender-id
VITE_FIREBASE_APP_ID=your-app-id
VITE_FIREBASE_DATABASE_URL=https://your-project.firebaseio.com
```

## Data Models

### Sensor Data Type

```typescript
interface SensorData {
  temperature: number;
  humidity: number;
  soilMoisture: number;
  pH: number;
  gasLevel: number;
  waterTemp: number;
  timestamp: number;
}

interface ProcessedData {
  soilStatus: "Dry" | "Normal";
  phStatus: "Acidic" | "Normal" | "Alkaline";
  gasStatus: "Safe" | "Danger";
  temperatureStatus: "High" | "Normal";
  humidityStatus: "High" | "Low" | "Normal";
  waterTempStatus: "Cold" | "Optimal" | "Warm";
  recommendation: string;
  processedAt: string;
}

interface ControlState {
  pump: boolean;
  fan: boolean;
  updatedAt: string;
}

interface Device {
  id: string;
  raw: SensorData;
  processed: ProcessedData;
  control: ControlState;
}
```

### Alert Type

```typescript
interface Alert {
  id: string;
  deviceId: string;
  type: string;
  severity: "Low" | "Medium" | "High";
  message: string;
  sensorValue: number;
  timestamp: number;
  isResolved: boolean;
  resolvedAt?: number;
}
```

## Custom Hooks

### useDeviceData Hook

Create `src/hooks/useDeviceData.ts`:

```typescript
import { useState, useEffect } from 'react';
import { ref, onValue, off } from 'firebase/database';
import { db } from '../config/firebase';

export function useDeviceData(deviceId: string) {
  const [rawData, setRawData] = useState(null);
  const [processedData, setProcessedData] = useState(null);
  const [controlData, setControlData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!deviceId) return;

    const rawRef = ref(db, `greenMonitorHub/devices/${deviceId}/raw`);
    const processedRef = ref(db, `greenMonitorHub/devices/${deviceId}/processed`);
    const controlRef = ref(db, `greenMonitorHub/devices/${deviceId}/control`);

    // Listen to raw data
    const unsubscribeRaw = onValue(
      rawRef,
      (snapshot) => {
        setRawData(snapshot.val());
        setLoading(false);
      },
      (error) => {
        setError(error.message);
        setLoading(false);
      }
    );

    // Listen to processed data
    const unsubscribeProcessed = onValue(
      processedRef,
      (snapshot) => {
        setProcessedData(snapshot.val());
      },
      (error) => {
        console.error('Error loading processed data:', error);
      }
    );

    // Listen to control data
    const unsubscribeControl = onValue(
      controlRef,
      (snapshot) => {
        setControlData(snapshot.val());
      },
      (error) => {
        console.error('Error loading control data:', error);
      }
    );

    return () => {
      off(rawRef);
      off(processedRef);
      off(controlRef);
    };
  }, [deviceId]);

  return { rawData, processedData, controlData, loading, error };
}
```

### useAlerts Hook

Create `src/hooks/useAlerts.ts`:

```typescript
import { useState, useEffect } from 'react';
import { ref, onValue, query, orderByChild, equalTo, limitToLast } from 'firebase/database';
import { db } from '../config/firebase';

export function useAlerts(deviceId: string, limit = 10) {
  const [alerts, setAlerts] = useState([]);
  const [unresolvedAlerts, setUnresolvedAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!deviceId) return;

    const alertsRef = ref(db, 'greenMonitorHub/alerts');
    const alertsQuery = query(
      alertsRef,
      orderByChild('deviceId'),
      equalTo(deviceId),
      limitToLast(limit)
    );

    const unsubscribe = onValue(
      alertsQuery,
      (snapshot) => {
        const data = snapshot.val();
        const alertList = data
          ? Object.entries(data).map(([id, alert]: any) => ({
              id,
              ...alert,
            }))
          : [];

        setAlerts(alertList.reverse());
        setUnresolvedAlerts(alertList.filter((a: any) => !a.isResolved));
        setLoading(false);
      },
      (error) => {
        console.error('Error loading alerts:', error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [deviceId, limit]);

  return { alerts, unresolvedAlerts, loading };
}
```

## Component Examples

### Sensor Dashboard Component

```typescript
import { useDeviceData } from '../hooks/useDeviceData';
import { StatCard } from './StatCard';
import { GaugeMeter } from './GaugeMeter';
import { TrendChart } from './TrendChart';

interface SensorDashboardProps {
  deviceId: string;
}

export function SensorDashboard({ deviceId }: SensorDashboardProps) {
  const { rawData, processedData, loading, error } = useDeviceData(deviceId);

  if (loading) return <div>Loading sensor data...</div>;
  if (error) return <div>Error: {error}</div>;
  if (!rawData || !processedData) return <div>No data available</div>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <StatCard
        title="Temperature"
        value={rawData.temperature}
        unit="°C"
        status={processedData.temperatureStatus}
        icon="🌡️"
      />

      <StatCard
        title="Humidity"
        value={rawData.humidity}
        unit="%"
        status={processedData.humidityStatus}
        icon="💧"
      />

      <StatCard
        title="Soil Moisture"
        value={rawData.soilMoisture}
        unit=""
        status={processedData.soilStatus}
        icon="🌱"
      />

      <StatCard
        title="pH Level"
        value={rawData.pH}
        unit=""
        status={processedData.phStatus}
        icon="⚖️"
      />

      <StatCard
        title="Gas Level"
        value={rawData.gasLevel}
        unit="ppm"
        status={processedData.gasStatus}
        icon="💨"
      />

      <StatCard
        title="Water Temperature"
        value={rawData.waterTemp}
        unit="°C"
        status={processedData.waterTempStatus}
        icon="💦"
      />

      <div className="col-span-full">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="font-bold mb-2">Recommendation</h3>
          <p className="text-gray-700">{processedData.recommendation}</p>
        </div>
      </div>

      <div className="col-span-full">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="font-bold mb-4">Control Status</h3>
          <div className="grid grid-cols-2 gap-4">
            <div
              className={`p-3 rounded ${
                rawData.control?.pump
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              <div className="font-bold">Pump</div>
              <div>{rawData.control?.pump ? 'ON' : 'OFF'}</div>
            </div>
            <div
              className={`p-3 rounded ${
                rawData.control?.fan
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              <div className="font-bold">Fan</div>
              <div>{rawData.control?.fan ? 'ON' : 'OFF'}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
```

### Alerts Component

```typescript
import { useAlerts } from '../hooks/useAlerts';
import { AlertCard } from './AlertCard';

interface AlertsPanelProps {
  deviceId: string;
}

export function AlertsPanel({ deviceId }: AlertsPanelProps) {
  const { alerts, unresolvedAlerts, loading } = useAlerts(deviceId);

  if (loading) return <div>Loading alerts...</div>;

  return (
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-bold mb-4">
          Alerts ({unresolvedAlerts.length} Unresolved)
        </h3>

        {unresolvedAlerts.length === 0 ? (
          <p className="text-gray-500">No active alerts</p>
        ) : (
          <div className="space-y-2">
            {unresolvedAlerts.map((alert) => (
              <AlertCard key={alert.id} alert={alert} deviceId={deviceId} />
            ))}
          </div>
        )}
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-bold mb-4">Recent Alerts</h3>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-3 rounded border-l-4 ${
                alert.severity === 'High'
                  ? 'border-red-500 bg-red-50'
                  : alert.severity === 'Medium'
                  ? 'border-yellow-500 bg-yellow-50'
                  : 'border-blue-500 bg-blue-50'
              }`}
            >
              <div className="flex justify-between">
                <div className="font-bold">{alert.type}</div>
                <div className="text-sm text-gray-500">
                  {new Date(alert.timestamp).toLocaleString()}
                </div>
              </div>
              <p className="text-sm mt-1">{alert.message}</p>
              {alert.isResolved && (
                <div className="text-xs text-gray-500 mt-1">
                  Resolved: {new Date(alert.resolvedAt).toLocaleString()}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
```

## Real-time Updates

The frontend automatically receives real-time updates through Firebase listeners:

```typescript
// Data updates in real-time without polling
onValue(ref(db, `greenMonitorHub/devices/${deviceId}/processed`), (snapshot) => {
  // UI updates automatically when backend processes new data
  setProcessedData(snapshot.val());
});
```

## Data Flow

```
ESP32 writes raw data
    ↓
Cloud Function processes data
    ↓
Processed data written to Firebase
    ↓
Frontend listener triggers
    ↓
React component re-renders with new data
    ↓
User sees updated dashboard
```

## Performance Optimization

### Lazy Loading

```typescript
const [selectedDevice, setSelectedDevice] = useState(null);

// Only load data for selected device
const { data } = useDeviceData(selectedDevice);
```

### Query Limitations

```typescript
// Limit alerts to last 10 for performance
const { alerts } = useAlerts(deviceId, 10);
```

### Unsubscribe on Unmount

```typescript
useEffect(() => {
  const unsubscribe = onValue(ref, callback);
  return () => unsubscribe();  // Clean up listener
}, []);
```

## Error Handling

```typescript
const { rawData, error } = useDeviceData(deviceId);

if (error) {
  return (
    <div className="alert alert-error">
      Connection lost: {error}
    </div>
  );
}
```

## Authentication

Optionally add user authentication:

```typescript
import { signInWithEmailAndPassword, signOutUser, onAuthStateChanged } from 'firebase/auth';
import { auth } from '../config/firebase';

export function useAuth() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, setUser);
    return unsubscribe;
  }, []);

  return {
    user,
    login: (email: string, password: string) =>
      signInWithEmailAndPassword(auth, email, password),
    logout: () => auth.signOut(),
  };
}
```

## Testing with Emulator

Run local Firebase emulator:

```bash
firebase emulators:start
```

Update Firebase config to use emulator:

```typescript
if (!import.meta.env.PROD) {
  connectDatabaseEmulator(db, 'localhost', 9000);
}
```

## Troubleshooting

### Data Not Updating

1. Check Firebase connection in browser DevTools
2. Verify database rules allow reads
3. Check browser console for errors
4. Ensure device ID is correct

### Performance Issues

1. Use limiting in queries
2. Unsubscribe from unused listeners
3. Implement virtual scrolling for long lists
4. Cache data when possible

### Authentication Errors

1. Verify Firebase config
2. Check user permissions in database rules
3. Ensure API key is correct

## Best Practices

- ✅ Clean up listeners on component unmount
- ✅ Implement error boundaries
- ✅ Use TypeScript for type safety
- ✅ Memoize expensive calculations
- ✅ Implement retry logic for failed queries
- ✅ Monitor Firebase usage in console
- ✅ Test with slow networks

## Resources

- [Firebase Docs](https://firebase.google.com/docs)
- [Realtime Database Reference](https://firebase.google.com/docs/database)
- [React Firebase Integration](https://www.robinwieruch.de/react-firebase/)

---

**Last Updated:** March 2, 2026
**Version:** 1.0.0
