/*
 * ============================================================================
 * GREEN MONITOR HUB - ESP32 Farm Monitoring System
 * Firmware for ESP32 Dev Board with Multiple Sensors
 * Author: Green Monitor Hub Team
 * Version: 1.0.0
 * ============================================================================
 * 
 * This firmware reads sensor data and sends it to Firebase Realtime Database.
 * It also reads control commands (pump, fan) from Firebase and activates relays.
 * 
 * Hardware Setup:
 * - ESP32 Development Board
 * - DHT22 (Temperature + Humidity) → GPIO 4
 * - DS18B20 (Water Temperature) → GPIO 5
 * - MQ-135 (Gas Sensor) → GPIO 35 (ADC)
 * - pH Sensor → GPIO 36 (ADC)
 * - Analog Humidity → GPIO 39 (ADC)
 * - Soil Moisture → GPIO 34 (ADC)
 * - Pump Relay → GPIO 12
 * - Fan Relay → GPIO 13
 * 
 * ============================================================================
 */

#include <WiFi.h>
#include <FirebaseESP32.h>
#include <DHT.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ArduinoJson.h>

// ============================================================================
// CONFIGURATION - Modify These Values
// ============================================================================

// WiFi Configuration
const char* WIFI_SSID = "YOUR_WIFI_SSID";           // Change this to your WiFi name
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";   // Change this to your WiFi password

// Firebase Configuration
const char* FIREBASE_HOST = "your-project.firebaseio.com";  // Change to your Firebase URL
const char* FIREBASE_AUTH = "YOUR_DATABASE_SECRET";         // Change to your Firebase secret (optional)

// Device Configuration
const char* DEVICE_ID = "device001";  // Unique device identifier
const char* DEVICE_NAME = "Farm Sensor 1";
const char* DEVICE_LOCATION = "Field A";

// Sensor Update Interval (milliseconds)
const unsigned long SENSOR_UPDATE_INTERVAL = 300000;  // 5 minutes (300,000ms)
const unsigned long CONTROL_CHECK_INTERVAL = 10000;   // 10 seconds (10,000ms)

// ============================================================================
// PIN CONFIGURATION
// ============================================================================

#define DHT_PIN 4              // DHT22 sensor pin
#define DHT_TYPE DHT22         // DHT22 sensor type
#define ONE_WIRE_BUS 5         // DS18B20 sensor pin
#define PUMP_RELAY_PIN 12      // Pump relay control pin
#define FAN_RELAY_PIN 13       // Fan relay control pin

// ADC Pins for analog sensors
#define GAS_SENSOR_PIN 35      // MQ-135 Gas sensor
#define PH_SENSOR_PIN 36       // pH sensor
#define HUMIDITY_SENSOR_PIN 39 // Analog humidity sensor
#define SOIL_MOISTURE_PIN 34   // Soil moisture sensor

// ============================================================================
// GLOBAL VARIABLES
// ============================================================================

// Firebase objects
FirebaseData firebaseData;
FirebaseConfig config;
FirebaseAuth auth;

// Sensor objects
DHT dht(DHT_PIN, DHT_TYPE);
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

// Timing variables
unsigned long lastSensorUpdate = 0;
unsigned long lastControlCheck = 0;
unsigned long lastWiFiCheck = 0;

// Current sensor readings
struct SensorData {
  float temperature;
  float humidity;
  float soilMoisture;
  float pH;
  float gasLevel;
  float waterTemp;
  unsigned long timestamp;
};

SensorData currentData;

// Control state
struct ControlState {
  bool pump;
  bool fan;
};

ControlState controlState = {false, false};
ControlState previousControlState = {false, false};

// ============================================================================
// SETUP FUNCTION
// ============================================================================

void setup() {
  // Initialize Serial Communication
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("\n\n");
  Serial.println("========================================");
  Serial.println("GREEN MONITOR HUB - ESP32 Firmware");
  Serial.println("Starting up...");
  Serial.println("========================================");
  
  // Initialize pins
  pinMode(PUMP_RELAY_PIN, OUTPUT);
  pinMode(FAN_RELAY_PIN, OUTPUT);
  digitalWrite(PUMP_RELAY_PIN, LOW);
  digitalWrite(FAN_RELAY_PIN, LOW);
  
  Serial.println("[SETUP] Relay pins initialized");
  
  // Initialize DHT sensor
  dht.begin();
  Serial.println("[SETUP] DHT22 sensor initialized on GPIO " + String(DHT_PIN));
  
  // Initialize OneWire sensors
  sensors.begin();
  Serial.println("[SETUP] DS18B20 sensor initialized on GPIO " + String(ONE_WIRE_BUS));
  
  // Initialize ADC
  analogSetAttenuation(ADC_11db);  // For better reading accuracy
  Serial.println("[SETUP] ADC configured for accurate readings");
  
  // Connect to WiFi
  connectToWiFi();
  
  // Configure Firebase
  configureFirebase();
  
  Serial.println("[SETUP] Initialization complete!");
  Serial.println("========================================\n");
}

// ============================================================================
// MAIN LOOP
// ============================================================================

void loop() {
  // Check WiFi connection periodically
  if (millis() - lastWiFiCheck > 30000) {  // Check every 30 seconds
    lastWiFiCheck = millis();
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("[ERROR] WiFi disconnected. Reconnecting...");
      connectToWiFi();
    }
  }
  
  // Read and send sensor data
  if (millis() - lastSensorUpdate >= SENSOR_UPDATE_INTERVAL) {
    lastSensorUpdate = millis();
    readSensorData();
    sendSensorDataToFirebase();
  }
  
  // Check and apply control commands
  if (millis() - lastControlCheck >= CONTROL_CHECK_INTERVAL) {
    lastControlCheck = millis();
    checkAndApplyControls();
  }
  
  delay(100);  // Small delay to prevent overwhelming the board
}

// ============================================================================
// WiFi Connection Function
// ============================================================================

void connectToWiFi() {
  Serial.println("[WiFi] Connecting to: " + String(WIFI_SSID));
  
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n[WiFi] Connected successfully!");
    Serial.println("[WiFi] IP Address: " + WiFi.localIP().toString());
    Serial.println("[WiFi] Signal Strength: " + String(WiFi.RSSI()) + " dBm");
  } else {
    Serial.println("\n[ERROR] Failed to connect to WiFi. Will retry...");
  }
}

// ============================================================================
// Firebase Configuration Function
// ============================================================================

void configureFirebase() {
  Serial.println("[Firebase] Configuring Firebase connection...");
  
  // Set Firebase host and auth
  config.host = FIREBASE_HOST;
  config.signer.tokens.legacy_token = FIREBASE_AUTH;
  
  // Optional: Set authentication method
  config.database_url = String("https://") + FIREBASE_HOST;
  
  // Initialize Firebase
  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);
  
  Serial.println("[Firebase] Firebase connection configured");
  Serial.println("[Firebase] Host: " + String(FIREBASE_HOST));
}

// ============================================================================
// SENSOR READING FUNCTION
// ============================================================================

void readSensorData() {
  Serial.println("\n[SENSOR] Reading sensor data...");
  
  // Read DHT22
  currentData.humidity = dht.readHumidity();
  currentData.temperature = dht.readTemperature();
  
  if (isnan(currentData.humidity) || isnan(currentData.temperature)) {
    Serial.println("[SENSOR] ERROR: Failed to read DHT22");
    currentData.temperature = 0;
    currentData.humidity = 0;
  } else {
    Serial.println("[SENSOR] Temperature: " + String(currentData.temperature) + "°C");
    Serial.println("[SENSOR] Humidity: " + String(currentData.humidity) + "%");
  }
  
  // Read DS18B20 Water Temperature
  sensors.requestTemperatures();
  currentData.waterTemp = sensors.getTempCByIndex(0);
  if (currentData.waterTemp == DEVICE_DISCONNECTED_C) {
    Serial.println("[SENSOR] ERROR: Failed to read water temperature");
    currentData.waterTemp = 0;
  } else {
    Serial.println("[SENSOR] Water Temperature: " + String(currentData.waterTemp) + "°C");
  }
  
  // Read Gas Level (MQ-135)
  int gasRaw = analogRead(GAS_SENSOR_PIN);
  currentData.gasLevel = map(gasRaw, 0, 4095, 0, 1000);  // Convert to ppm (0-1000)
  Serial.println("[SENSOR] Gas Level: " + String(currentData.gasLevel) + " ppm (raw: " + String(gasRaw) + ")");
  
  // Read pH Sensor
  int phRaw = analogRead(PH_SENSOR_PIN);
  currentData.pH = map(phRaw, 0, 4095, 0, 14);  // Convert to pH (0-14)
  Serial.println("[SENSOR] pH Level: " + String(currentData.pH));
  
  // Read Analog Humidity Sensor
  int humidityRaw = analogRead(HUMIDITY_SENSOR_PIN);
  float analogHumidity = map(humidityRaw, 0, 4095, 0, 100);  // Convert to percentage
  
  // Read Soil Moisture Sensor
  int soilRaw = analogRead(SOIL_MOISTURE_PIN);
  currentData.soilMoisture = map(soilRaw, 0, 4095, 0, 1024);  // Convert to 0-1024 scale
  Serial.println("[SENSOR] Soil Moisture: " + String(currentData.soilMoisture) + " (raw: " + String(soilRaw) + ")");
  
  // Set timestamp
  currentData.timestamp = millis() / 1000;  // Seconds since startup
  
  Serial.println("[SENSOR] Sensor reading complete!");
}

// ============================================================================
// SEND DATA TO FIREBASE FUNCTION
// ============================================================================

void sendSensorDataToFirebase() {
  Serial.println("\n[Firebase] Sending sensor data to Firebase...");
  
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[ERROR] WiFi not connected. Cannot send data.");
    return;
  }
  
  if (!Firebase.ready()) {
    Serial.println("[ERROR] Firebase not ready. Will retry next time.");
    return;
  }
  
  // Create JSON object with sensor data
  StaticJsonDocument<256> doc;
  doc["temperature"] = currentData.temperature;
  doc["humidity"] = currentData.humidity;
  doc["soilMoisture"] = currentData.soilMoisture;
  doc["pH"] = currentData.pH;
  doc["gasLevel"] = currentData.gasLevel;
  doc["waterTemp"] = currentData.waterTemp;
  doc["timestamp"] = currentData.timestamp;
  
  // Convert JSON to string
  String jsonData;
  serializeJson(doc, jsonData);
  
  // Send to Firebase
  String path = String("greenMonitorHub/devices/") + DEVICE_ID + "/raw";
  
  if (Firebase.RTDB.setJSON(&firebaseData, path, &doc)) {
    Serial.println("[Firebase] ✓ Data sent successfully!");
    Serial.println("[Firebase] Path: " + path);
    Serial.println("[Firebase] Payload: " + jsonData);
  } else {
    Serial.println("[Firebase] ✗ Error sending data!");
    Serial.println("[Firebase] Error: " + firebaseData.errorMessage());
  }
}

// ============================================================================
// CHECK AND APPLY CONTROL COMMANDS FUNCTION
// ============================================================================

void checkAndApplyControls() {
  Serial.println("\n[Control] Checking for control commands...");
  
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[Control] WiFi not connected. Skipping control check.");
    return;
  }
  
  if (!Firebase.ready()) {
    Serial.println("[Control] Firebase not ready. Skipping control check.");
    return;
  }
  
  // Get control state from Firebase
  String controlPath = String("greenMonitorHub/devices/") + DEVICE_ID + "/control";
  
  if (Firebase.RTDB.getJSON(&firebaseData, controlPath)) {
    if (firebaseData.dataType() == "json") {
      StaticJsonDocument<128> doc;
      deserializeJson(doc, firebaseData.to<String>());
      
      controlState.pump = doc["pump"] | false;
      controlState.fan = doc["fan"] | false;
      
      Serial.println("[Control] ✓ Control commands received!");
      Serial.println("[Control] Pump: " + String(controlState.pump ? "ON" : "OFF"));
      Serial.println("[Control] Fan: " + String(controlState.fan ? "ON" : "OFF"));
      
      // Apply control commands if changed
      if (controlState.pump != previousControlState.pump) {
        digitalWrite(PUMP_RELAY_PIN, controlState.pump ? HIGH : LOW);
        String status = controlState.pump ? "ACTIVATED" : "DEACTIVATED";
        Serial.println("[Control] ⚙️ Pump " + status);
        previousControlState.pump = controlState.pump;
      }
      
      if (controlState.fan != previousControlState.fan) {
        digitalWrite(FAN_RELAY_PIN, controlState.fan ? HIGH : LOW);
        String status = controlState.fan ? "ACTIVATED" : "DEACTIVATED";
        Serial.println("[Control] ⚙️ Fan " + status);
        previousControlState.fan = controlState.fan;
      }
    } else {
      Serial.println("[Control] No control data available yet");
    }
  } else {
    Serial.println("[Control] Error reading control commands");
    Serial.println("[Control] Error: " + firebaseData.errorMessage());
  }
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

// Function to get device info
void printDeviceInfo() {
  Serial.println("\n========================================");
  Serial.println("DEVICE INFORMATION");
  Serial.println("========================================");
  Serial.println("Device ID: " + String(DEVICE_ID));
  Serial.println("Device Name: " + String(DEVICE_NAME));
  Serial.println("Location: " + String(DEVICE_LOCATION));
  Serial.println("Firmware Version: 1.0.0");
  Serial.println("Update Interval: " + String(SENSOR_UPDATE_INTERVAL / 1000) + " seconds");
  Serial.println("Control Check Interval: " + String(CONTROL_CHECK_INTERVAL / 1000) + " seconds");
  Serial.println("========================================\n");
}

// ============================================================================
// END OF CODE
// ============================================================================

/*
 * INSTALLATION INSTRUCTIONS:
 * 
 * 1. Install Arduino IDE
 * 2. Add ESP32 board support:
 *    Preferences → Additional Boards Manager URLs
 *    Add: https://dl.espressif.com/dl/package_esp32_index.json
 * 
 * 3. Install required libraries:
 *    - FirebaseESP32 (by Mobizt)
 *    - DHT sensor library (by Adafruit)
 *    - DallasTemperature (by Miles Burton)
 *    - OneWire (by Jim Studt)
 *    - ArduinoJson (by Benoit Blanchon)
 * 
 * 4. CONFIGURATION:
 *    Update these values with YOUR information:
 *    - WIFI_SSID = your WiFi name
 *    - WIFI_PASSWORD = your WiFi password
 *    - FIREBASE_HOST = your Firebase URL
 *    - DEVICE_ID = unique device identifier
 * 
 * 5. SELECT BOARD:
 *    Tools → Board → ESP32 Dev Module
 *    Tools → Port → Select COM port
 * 
 * 6. UPLOAD:
 *    Sketch → Upload (or press Ctrl+U)
 * 
 * 7. MONITOR:
 *    Tools → Serial Monitor (115200 baud)
 *    Watch the output for status messages
 * 
 * PINOUT REFERENCE:
 * GPIO 4  → DHT22 (Temperature + Humidity)
 * GPIO 5  → DS18B20 (Water Temperature)
 * GPIO 12 → Pump Relay
 * GPIO 13 → Fan Relay
 * GPIO 35 → Gas Sensor (MQ-135)
 * GPIO 36 → pH Sensor
 * GPIO 39 → Humidity Sensor
 * GPIO 34 → Soil Moisture Sensor
 * 
 * DATA FORMAT:
 * Sends to: /greenMonitorHub/devices/{DEVICE_ID}/raw
 * {
 *   "temperature": 28.5,
 *   "humidity": 65.0,
 *   "soilMoisture": 450.0,
 *   "pH": 6.8,
 *   "gasLevel": 400.0,
 *   "waterTemp": 22.5,
 *   "timestamp": 3600
 * }
 * 
 * TROUBLE SHOOTING:
 * 
 * 1. Upload fails:
 *    - Check COM port is selected
 *    - Try different baud rate if needed
 *    - Hold BOOT button while uploading
 * 
 * 2. WiFi won't connect:
 *    - Check SSID and password are correct
 *    - ESP32 requires 2.4GHz WiFi (not 5GHz)
 *    - Check signal strength (Serial output shows signal)
 * 
 * 3. Firebase connection fails:
 *    - Check Firebase host URL is correct
 *    - Verify database rules in Firebase console
 *    - Check Internet connection
 * 
 * 4. Sensors not reading:
 *    - Check sensor connections
 *    - Verify GPIO pins match your wiring
 *    - Check sensor power supply
 *    - Use Serial Monitor to debug
 * 
 * 5. Serial Monitor blank:
 *    - Change baud rate to 115200
 *    - Press ESP32 reset button
 *    - Check USB cable connection
 */
